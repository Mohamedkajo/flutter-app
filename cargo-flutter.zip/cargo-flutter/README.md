# Cargo — Flutter Mobile App

A production-ready Flutter mobile app for the **Cargo** multi-vendor marketplace platform.  
Connects to the Cargo REST API (Node.js/Express/PostgreSQL on Replit).

---

## Getting Started

### Prerequisites

- Flutter SDK ≥ 3.3.0 (install via [flutter.dev](https://flutter.dev/docs/get-started/install))
- Dart ≥ 3.3.0
- Android Studio or Xcode
- A running Cargo API backend

### 1. Configure the API URL

Open `lib/config/api_config.dart` and replace the base URL:

```dart
static const String baseUrl = 'https://YOUR_REPLIT_DOMAIN/api';
```

Replace `YOUR_REPLIT_DOMAIN` with your Replit dev domain, e.g.:
```
https://cargo.username.replit.dev/api
```

### 2. Install dependencies

```bash
flutter pub get
```

### 3. Run the app

```bash
# Android
flutter run -d android

# iOS (macOS only)
flutter run -d ios

# Web (preview)
flutter run -d chrome
```

---

## Project Structure

```
lib/
├── main.dart                   # App entry point
├── config/
│   └── api_config.dart         # API base URL + auth config
├── theme/
│   └── app_theme.dart          # Brand colors, typography, component styles
├── models/                     # Data models (Category, Store, Product, Cart, Order, User...)
├── services/
│   └── api_service.dart        # All API calls (Dio-based singleton)
├── providers/                  # State management (Provider)
│   ├── auth_provider.dart
│   ├── cart_provider.dart
│   └── app_provider.dart
├── router/
│   └── app_router.dart         # GoRouter with auth guard + bottom nav shell
├── screens/
│   ├── auth/                   # Login, Register
│   ├── home/                   # Home feed
│   ├── store/                  # Store listing, Store detail
│   ├── product/                # Product detail
│   ├── cart/                   # Cart + checkout
│   ├── orders/                 # Orders list, Order tracking
│   ├── wallet/                 # Wallet + transactions
│   ├── notifications/          # Notifications
│   ├── search/                 # Search (stores + products)
│   ├── profile/                # Profile + settings
│   └── shell/                  # Bottom navigation shell
└── widgets/
    ├── store_card.dart          # Store card + story circle
    ├── product_card.dart        # Product card (grid + horizontal)
    ├── flash_sale_banner.dart   # Animated countdown banner
    └── common/
        ├── cargo_button.dart    # Branded button component
        ├── section_header.dart  # Section title + "See All"
        └── loading_shimmer.dart # Skeleton loading states
```

---

## Brand

| Token | Value |
|-------|-------|
| Primary | `#5E2D91` |
| Primary Dark | `#47206E` |
| Accent (Coral) | `#F25B57` |
| Amber | `#F6A623` |
| Surface | `#F8F8FC` |
| Font | Poppins |

---

## Demo Credentials

These work against the seeded Cargo backend:

| Role | Email | Password |
|------|-------|----------|
| Customer | `ahmed@example.com` | `password123` |
| Driver | `driver@example.com` | `password123` |
| Merchant | `merchant@example.com` | `password123` |
| Admin | `admin@cargo.com` | `admin123` |

---

## Key Dependencies

| Package | Purpose |
|---------|---------|
| `go_router` | Declarative routing + auth guard |
| `provider` | Lightweight state management |
| `dio` | HTTP client |
| `cached_network_image` | Image caching |
| `google_fonts` | Poppins font |
| `shimmer` | Skeleton loading |
| `badges` | Cart count badge |
| `flutter_rating_bar` | Star ratings |
| `fl_chart` | Charts (analytics) |
| `shared_preferences` | Token/user persistence |

---

## Extending the App

- **Merchant Dashboard**: Create screens under `screens/merchant/` — connect to `/merchant/orders`, `/merchant/products`, `/merchant/profile`
- **Driver App**: Create screens under `screens/driver/` — connect to `/drivers/profile`, `/drivers/orders`, `/drivers/earnings`
- **Admin Dashboard**: Create screens under `screens/admin/` — connect to `/analytics/summary`, `/analytics/revenue-trend`
- **Push Notifications**: Integrate `firebase_messaging` + FCM
- **Google Maps**: Replace the map placeholder in `order_tracking_screen.dart` with `google_maps_flutter`
- **Payment**: Integrate Stripe or Paymob for card payments

---

## Building for Production

```bash
# Android APK
flutter build apk --release

# Android App Bundle (Play Store)
flutter build appbundle --release

# iOS (requires macOS + Xcode)
flutter build ipa --release
```

Remember to:
1. Update `ApiConfig.baseUrl` to your production API URL
2. Sign the app with your release keystore (Android) or provisioning profile (iOS)
3. Update `android/app/src/main/AndroidManifest.xml` package name
4. Update `pubspec.yaml` version/build number
