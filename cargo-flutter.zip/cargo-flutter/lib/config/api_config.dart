class ApiConfig {
  // Replace with your Replit dev domain or production URL
  // e.g. 'https://<repl-name>.<username>.repl.co/api'
  static const String baseUrl = 'https://YOUR_REPLIT_DOMAIN/api';

  // Timeouts
  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration receiveTimeout = Duration(seconds: 30);

  // Auth header key
  static const String authHeaderKey = 'Authorization';
  static const String authHeaderPrefix = 'Bearer ';

  // Local storage keys
  static const String tokenKey = 'cargo_token';
  static const String userKey = 'cargo_user';
}
