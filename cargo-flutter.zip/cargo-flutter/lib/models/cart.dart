class Cart {
  final int id;
  final int? storeId;
  final String? storeName;
  final List<CartItem> items;
  final double subtotal;
  final double deliveryFee;
  final double discount;
  final double total;
  final String? couponCode;

  const Cart({
    required this.id,
    this.storeId,
    this.storeName,
    required this.items,
    required this.subtotal,
    required this.deliveryFee,
    required this.discount,
    required this.total,
    this.couponCode,
  });

  factory Cart.fromJson(Map<String, dynamic> json) => Cart(
        id: json['id'] as int,
        storeId: json['storeId'] as int?,
        storeName: json['storeName'] as String?,
        items: (json['items'] as List<dynamic>)
            .map((e) => CartItem.fromJson(e as Map<String, dynamic>))
            .toList(),
        subtotal: (json['subtotal'] as num).toDouble(),
        deliveryFee: (json['deliveryFee'] as num).toDouble(),
        discount: (json['discount'] as num).toDouble(),
        total: (json['total'] as num).toDouble(),
        couponCode: json['couponCode'] as String?,
      );

  int get itemCount => items.fold(0, (sum, i) => sum + i.quantity);
  bool get isEmpty => items.isEmpty;
}

class CartItem {
  final int id;
  final int cartId;
  final int productId;
  final String name;
  final String image;
  final double price;
  final int quantity;
  final String? variant;
  final List<String> addons;
  final String? specialInstructions;

  const CartItem({
    required this.id,
    required this.cartId,
    required this.productId,
    required this.name,
    required this.image,
    required this.price,
    required this.quantity,
    this.variant,
    required this.addons,
    this.specialInstructions,
  });

  factory CartItem.fromJson(Map<String, dynamic> json) => CartItem(
        id: json['id'] as int,
        cartId: json['cartId'] as int,
        productId: json['productId'] as int,
        name: json['name'] as String,
        image: json['image'] as String,
        price: (json['price'] as num).toDouble(),
        quantity: json['quantity'] as int,
        variant: json['variant'] as String?,
        addons: (json['addons'] as List<dynamic>?)?.map((e) => e as String).toList() ?? [],
        specialInstructions: json['specialInstructions'] as String?,
      );

  double get subtotal => price * quantity;
}
