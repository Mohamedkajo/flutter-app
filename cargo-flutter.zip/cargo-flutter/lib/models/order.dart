class Order {
  final int id;
  final int userId;
  final int storeId;
  final String storeName;
  final String? storeImage;
  final int? driverId;
  final String? driverName;
  final String status;
  final double subtotal;
  final double deliveryFee;
  final double discount;
  final double total;
  final String paymentMethod;
  final String deliveryAddress;
  final String? estimatedDelivery;
  final String? specialInstructions;
  final String? couponCode;
  final int itemCount;
  final List<OrderItem> items;
  final List<OrderTimeline> timeline;
  final String createdAt;
  final String updatedAt;

  const Order({
    required this.id,
    required this.userId,
    required this.storeId,
    required this.storeName,
    this.storeImage,
    this.driverId,
    this.driverName,
    required this.status,
    required this.subtotal,
    required this.deliveryFee,
    required this.discount,
    required this.total,
    required this.paymentMethod,
    required this.deliveryAddress,
    this.estimatedDelivery,
    this.specialInstructions,
    this.couponCode,
    required this.itemCount,
    this.items = const [],
    this.timeline = const [],
    required this.createdAt,
    required this.updatedAt,
  });

  factory Order.fromJson(Map<String, dynamic> json) => Order(
        id: json['id'] as int,
        userId: json['userId'] as int,
        storeId: json['storeId'] as int,
        storeName: json['storeName'] as String,
        storeImage: json['storeImage'] as String?,
        driverId: json['driverId'] as int?,
        driverName: json['driverName'] as String?,
        status: json['status'] as String,
        subtotal: (json['subtotal'] as num).toDouble(),
        deliveryFee: (json['deliveryFee'] as num).toDouble(),
        discount: (json['discount'] as num).toDouble(),
        total: (json['total'] as num).toDouble(),
        paymentMethod: json['paymentMethod'] as String,
        deliveryAddress: json['deliveryAddress'] as String,
        estimatedDelivery: json['estimatedDelivery'] as String?,
        specialInstructions: json['specialInstructions'] as String?,
        couponCode: json['couponCode'] as String?,
        itemCount: json['itemCount'] as int? ?? 1,
        items: (json['items'] as List<dynamic>?)
                ?.map((e) => OrderItem.fromJson(e as Map<String, dynamic>))
                .toList() ??
            [],
        timeline: (json['timeline'] as List<dynamic>?)
                ?.map((e) => OrderTimeline.fromJson(e as Map<String, dynamic>))
                .toList() ??
            [],
        createdAt: json['createdAt'] as String,
        updatedAt: json['updatedAt'] as String,
      );

  bool get isActive => ['pending', 'accepted', 'preparing', 'packed',
      'driver_assigned', 'picked_up', 'delivering'].contains(status);
  bool get isCompleted => status == 'completed' || status == 'delivered';
  bool get isCancelled => status == 'cancelled';

  String get statusLabel => switch (status) {
        'pending' => 'Order Placed',
        'accepted' => 'Order Accepted',
        'preparing' => 'Preparing',
        'packed' => 'Packed',
        'driver_assigned' => 'Driver Assigned',
        'picked_up' => 'Picked Up',
        'delivering' => 'On The Way',
        'delivered' => 'Delivered',
        'completed' => 'Completed',
        'cancelled' => 'Cancelled',
        _ => status,
      };
}

class OrderItem {
  final int id;
  final int orderId;
  final int productId;
  final String name;
  final String image;
  final double price;
  final int quantity;
  final String? variant;
  final List<String> addons;
  final String? specialInstructions;

  const OrderItem({
    required this.id,
    required this.orderId,
    required this.productId,
    required this.name,
    required this.image,
    required this.price,
    required this.quantity,
    this.variant,
    required this.addons,
    this.specialInstructions,
  });

  factory OrderItem.fromJson(Map<String, dynamic> json) => OrderItem(
        id: json['id'] as int,
        orderId: json['orderId'] as int,
        productId: json['productId'] as int,
        name: json['name'] as String,
        image: json['image'] as String,
        price: (json['price'] as num).toDouble(),
        quantity: json['quantity'] as int,
        variant: json['variant'] as String?,
        addons: (json['addons'] as List<dynamic>?)?.map((e) => e as String).toList() ?? [],
        specialInstructions: json['specialInstructions'] as String?,
      );
}

class OrderTimeline {
  final String status;
  final String timestamp;
  final String label;
  final bool completed;

  const OrderTimeline({
    required this.status,
    required this.timestamp,
    required this.label,
    required this.completed,
  });

  factory OrderTimeline.fromJson(Map<String, dynamic> json) => OrderTimeline(
        status: json['status'] as String,
        timestamp: json['timestamp'] as String,
        label: json['label'] as String,
        completed: json['completed'] as bool? ?? false,
      );
}

class OrderTracking {
  final int orderId;
  final String status;
  final String? eta;
  final String? driverName;
  final String? driverPhone;
  final String? driverAvatar;
  final double? driverRating;
  final double? driverLat;
  final double? driverLng;
  final String storeAddress;
  final String deliveryAddress;
  final List<OrderTimeline> timeline;

  const OrderTracking({
    required this.orderId,
    required this.status,
    this.eta,
    this.driverName,
    this.driverPhone,
    this.driverAvatar,
    this.driverRating,
    this.driverLat,
    this.driverLng,
    required this.storeAddress,
    required this.deliveryAddress,
    required this.timeline,
  });

  factory OrderTracking.fromJson(Map<String, dynamic> json) => OrderTracking(
        orderId: json['orderId'] as int,
        status: json['status'] as String,
        eta: json['eta'] as String?,
        driverName: json['driverName'] as String?,
        driverPhone: json['driverPhone'] as String?,
        driverAvatar: json['driverAvatar'] as String?,
        driverRating: (json['driverRating'] as num?)?.toDouble(),
        driverLat: (json['driverLat'] as num?)?.toDouble(),
        driverLng: (json['driverLng'] as num?)?.toDouble(),
        storeAddress: json['storeAddress'] as String,
        deliveryAddress: json['deliveryAddress'] as String,
        timeline: (json['timeline'] as List<dynamic>?)
                ?.map((e) => OrderTimeline.fromJson(e as Map<String, dynamic>))
                .toList() ??
            [],
      );
}
