class Product {
  final int id;
  final int storeId;
  final String storeName;
  final String name;
  final String? description;
  final double price;
  final double? originalPrice;
  final String image;
  final String categoryName;
  final double rating;
  final int reviewCount;
  final bool isAvailable;
  final bool isFeatured;
  final int? discountPercent;
  final List<String> tags;
  final String? preparationTime;
  final List<ProductVariant> variants;
  final List<ProductAddon> addons;
  final List<String> gallery;

  const Product({
    required this.id,
    required this.storeId,
    required this.storeName,
    required this.name,
    this.description,
    required this.price,
    this.originalPrice,
    required this.image,
    required this.categoryName,
    required this.rating,
    required this.reviewCount,
    required this.isAvailable,
    required this.isFeatured,
    this.discountPercent,
    required this.tags,
    this.preparationTime,
    this.variants = const [],
    this.addons = const [],
    this.gallery = const [],
  });

  factory Product.fromJson(Map<String, dynamic> json) => Product(
        id: json['id'] as int,
        storeId: json['storeId'] as int,
        storeName: json['storeName'] as String,
        name: json['name'] as String,
        description: json['description'] as String?,
        price: (json['price'] as num).toDouble(),
        originalPrice: (json['originalPrice'] as num?)?.toDouble(),
        image: json['image'] as String,
        categoryName: json['categoryName'] as String,
        rating: (json['rating'] as num?)?.toDouble() ?? 4.3,
        reviewCount: json['reviewCount'] as int? ?? 0,
        isAvailable: json['isAvailable'] as bool? ?? true,
        isFeatured: json['isFeatured'] as bool? ?? false,
        discountPercent: json['discountPercent'] as int?,
        tags: (json['tags'] as List<dynamic>?)?.map((e) => e as String).toList() ?? [],
        preparationTime: json['preparationTime'] as String?,
        variants: (json['variants'] as List<dynamic>?)
                ?.map((e) => ProductVariant.fromJson(e as Map<String, dynamic>))
                .toList() ??
            [],
        addons: (json['addons'] as List<dynamic>?)
                ?.map((e) => ProductAddon.fromJson(e as Map<String, dynamic>))
                .toList() ??
            [],
        gallery: (json['gallery'] as List<dynamic>?)?.map((e) => e as String).toList() ?? [],
      );

  bool get hasDiscount => discountPercent != null && discountPercent! > 0;
  double get effectivePrice => hasDiscount
      ? price * (1 - discountPercent! / 100)
      : price;
}

class ProductVariant {
  final int id;
  final String name;
  final double price;
  final bool isAvailable;

  const ProductVariant({
    required this.id,
    required this.name,
    required this.price,
    required this.isAvailable,
  });

  factory ProductVariant.fromJson(Map<String, dynamic> json) => ProductVariant(
        id: json['id'] as int,
        name: json['name'] as String,
        price: (json['price'] as num).toDouble(),
        isAvailable: json['isAvailable'] as bool? ?? true,
      );
}

class ProductAddon {
  final int id;
  final String name;
  final double price;

  const ProductAddon({
    required this.id,
    required this.name,
    required this.price,
  });

  factory ProductAddon.fromJson(Map<String, dynamic> json) => ProductAddon(
        id: json['id'] as int,
        name: json['name'] as String,
        price: (json['price'] as num).toDouble(),
      );
}
