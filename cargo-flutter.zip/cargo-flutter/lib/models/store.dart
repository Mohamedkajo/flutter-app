class Store {
  final int id;
  final String name;
  final String slug;
  final String? description;
  final String? logo;
  final String image;
  final String? bannerImage;
  final String categoryName;
  final String? categoryIcon;
  final String? address;
  final String? phone;
  final double rating;
  final int reviewCount;
  final String deliveryTime;
  final double deliveryFee;
  final double minOrder;
  final bool isOpen;
  final bool isFeatured;
  final bool isVerified;
  final bool isTrending;
  final double? distance;
  final List<String> tags;
  final List<String> productCategories;

  const Store({
    required this.id,
    required this.name,
    required this.slug,
    this.description,
    this.logo,
    required this.image,
    this.bannerImage,
    required this.categoryName,
    this.categoryIcon,
    this.address,
    this.phone,
    required this.rating,
    required this.reviewCount,
    required this.deliveryTime,
    required this.deliveryFee,
    required this.minOrder,
    required this.isOpen,
    required this.isFeatured,
    required this.isVerified,
    required this.isTrending,
    this.distance,
    required this.tags,
    required this.productCategories,
  });

  factory Store.fromJson(Map<String, dynamic> json) => Store(
        id: json['id'] as int,
        name: json['name'] as String,
        slug: json['slug'] as String,
        description: json['description'] as String?,
        logo: json['logo'] as String?,
        image: json['image'] as String,
        bannerImage: json['bannerImage'] as String?,
        categoryName: json['categoryName'] as String,
        categoryIcon: json['categoryIcon'] as String?,
        address: json['address'] as String?,
        phone: json['phone'] as String?,
        rating: (json['rating'] as num).toDouble(),
        reviewCount: json['reviewCount'] as int? ?? 0,
        deliveryTime: json['deliveryTime'] as String? ?? '20-30 Min',
        deliveryFee: (json['deliveryFee'] as num?)?.toDouble() ?? 10,
        minOrder: (json['minOrder'] as num?)?.toDouble() ?? 50,
        isOpen: json['isOpen'] as bool? ?? true,
        isFeatured: json['isFeatured'] as bool? ?? false,
        isVerified: json['isVerified'] as bool? ?? false,
        isTrending: json['isTrending'] as bool? ?? false,
        distance: (json['distance'] as num?)?.toDouble(),
        tags: (json['tags'] as List<dynamic>?)?.map((e) => e as String).toList() ?? [],
        productCategories: (json['productCategories'] as List<dynamic>?)?.map((e) => e as String).toList() ?? [],
      );
}
