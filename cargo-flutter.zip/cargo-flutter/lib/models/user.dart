class User {
  final int id;
  final String name;
  final String email;
  final String? phone;
  final String? avatar;
  final String role;
  final int loyaltyPoints;
  final String createdAt;

  const User({
    required this.id,
    required this.name,
    required this.email,
    this.phone,
    this.avatar,
    required this.role,
    required this.loyaltyPoints,
    required this.createdAt,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
        id: json['id'] as int,
        name: json['name'] as String,
        email: json['email'] as String,
        phone: json['phone'] as String?,
        avatar: json['avatar'] as String?,
        role: json['role'] as String,
        loyaltyPoints: json['loyaltyPoints'] as int? ?? 0,
        createdAt: json['createdAt'] as String,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'email': email,
        'phone': phone,
        'avatar': avatar,
        'role': role,
        'loyaltyPoints': loyaltyPoints,
        'createdAt': createdAt,
      };

  String get firstName => name.split(' ').first;
  String get initials {
    final parts = name.trim().split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return parts[0][0].toUpperCase();
  }
}

class Wallet {
  final int id;
  final int userId;
  final double balance;
  final String currency;
  final int loyaltyPoints;

  const Wallet({
    required this.id,
    required this.userId,
    required this.balance,
    required this.currency,
    required this.loyaltyPoints,
  });

  factory Wallet.fromJson(Map<String, dynamic> json) => Wallet(
        id: json['id'] as int,
        userId: json['userId'] as int,
        balance: (json['balance'] as num).toDouble(),
        currency: json['currency'] as String? ?? 'EGP',
        loyaltyPoints: json['loyaltyPoints'] as int? ?? 0,
      );
}

class WalletTransaction {
  final int id;
  final String type;
  final double amount;
  final String description;
  final int? orderId;
  final String createdAt;

  const WalletTransaction({
    required this.id,
    required this.type,
    required this.amount,
    required this.description,
    this.orderId,
    required this.createdAt,
  });

  factory WalletTransaction.fromJson(Map<String, dynamic> json) => WalletTransaction(
        id: json['id'] as int,
        type: json['type'] as String,
        amount: (json['amount'] as num).toDouble(),
        description: json['description'] as String,
        orderId: json['orderId'] as int?,
        createdAt: json['createdAt'] as String,
      );

  bool get isCredit => type == 'credit' || type == 'refund' || type == 'reward';
}

class Notification {
  final int id;
  final String title;
  final String body;
  final String type;
  final bool isRead;
  final int? orderId;
  final String? image;
  final String createdAt;

  const Notification({
    required this.id,
    required this.title,
    required this.body,
    required this.type,
    required this.isRead,
    this.orderId,
    this.image,
    required this.createdAt,
  });

  factory Notification.fromJson(Map<String, dynamic> json) => Notification(
        id: json['id'] as int,
        title: json['title'] as String,
        body: json['body'] as String,
        type: json['type'] as String,
        isRead: json['isRead'] as bool? ?? false,
        orderId: json['orderId'] as int?,
        image: json['image'] as String?,
        createdAt: json['createdAt'] as String,
      );
}

class Coupon {
  final int id;
  final String code;
  final String title;
  final String? description;
  final double discount;
  final String type;
  final double? minOrder;
  final double? maxDiscount;
  final String expiresAt;
  final bool isActive;
  final bool isUsed;

  const Coupon({
    required this.id,
    required this.code,
    required this.title,
    this.description,
    required this.discount,
    required this.type,
    this.minOrder,
    this.maxDiscount,
    required this.expiresAt,
    required this.isActive,
    required this.isUsed,
  });

  factory Coupon.fromJson(Map<String, dynamic> json) => Coupon(
        id: json['id'] as int,
        code: json['code'] as String,
        title: json['title'] as String,
        description: json['description'] as String?,
        discount: (json['discount'] as num).toDouble(),
        type: json['type'] as String,
        minOrder: (json['minOrder'] as num?)?.toDouble(),
        maxDiscount: (json['maxDiscount'] as num?)?.toDouble(),
        expiresAt: json['expiresAt'] as String,
        isActive: json['isActive'] as bool? ?? true,
        isUsed: json['isUsed'] as bool? ?? false,
      );

  String get discountLabel =>
      type == 'percentage' ? '${discount.toInt()}% OFF' : 'EGP ${discount.toInt()} OFF';
}

class FlashSale {
  final int id;
  final String title;
  final String? description;
  final String? bannerImage;
  final String endsAt;
  final int discountPercent;
  final bool isActive;
  final List<dynamic> products;

  const FlashSale({
    required this.id,
    required this.title,
    this.description,
    this.bannerImage,
    required this.endsAt,
    required this.discountPercent,
    required this.isActive,
    required this.products,
  });

  factory FlashSale.fromJson(Map<String, dynamic> json) => FlashSale(
        id: json['id'] as int,
        title: json['title'] as String,
        description: json['description'] as String?,
        bannerImage: json['bannerImage'] as String?,
        endsAt: json['endsAt'] as String,
        discountPercent: json['discountPercent'] as int? ?? 20,
        isActive: json['isActive'] as bool? ?? true,
        products: json['products'] as List<dynamic>? ?? [],
      );

  Duration get timeRemaining => DateTime.parse(endsAt).difference(DateTime.now());
}
