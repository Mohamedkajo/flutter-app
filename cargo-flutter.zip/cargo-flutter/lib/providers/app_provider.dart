import 'package:flutter/material.dart';
import '../models/category.dart';
import '../models/store.dart';
import '../models/product.dart';
import '../models/user.dart';
import '../services/api_service.dart';

class AppProvider extends ChangeNotifier {
  // Home data
  List<Category> categories = [];
  List<Store> featuredStores = [];
  List<Store> nearbyStores = [];
  List<Product> trendingProducts = [];
  List<FlashSale> flashSales = [];
  bool homeLoading = false;

  // Notifications
  List<Notification> notifications = [];
  int get unreadCount => notifications.where((n) => !n.isRead).length;

  // Wallet
  Wallet? wallet;

  // Favorites
  Set<int> favoriteStoreIds = {};
  Set<int> favoriteProductIds = {};

  Future<void> loadHomeData() async {
    homeLoading = true;
    notifyListeners();
    try {
      final results = await Future.wait([
        apiService.getCategories(),
        apiService.getFeaturedStores(),
        apiService.getNearbyStores(),
        apiService.getTrendingProducts(),
        apiService.getFlashSales(),
      ]);
      categories = results[0] as List<Category>;
      featuredStores = results[1] as List<Store>;
      nearbyStores = results[2] as List<Store>;
      trendingProducts = results[3] as List<Product>;
      flashSales = results[4] as List<FlashSale>;
    } catch (_) {}
    homeLoading = false;
    notifyListeners();
  }

  Future<void> loadNotifications() async {
    try {
      notifications = await apiService.getNotifications();
      notifyListeners();
    } catch (_) {}
  }

  Future<void> markRead(int notificationId) async {
    try {
      final updated = await apiService.markNotificationRead(notificationId);
      final idx = notifications.indexWhere((n) => n.id == notificationId);
      if (idx != -1) notifications[idx] = updated;
      notifyListeners();
    } catch (_) {}
  }

  Future<void> loadWallet() async {
    try {
      wallet = await apiService.getWallet();
      notifyListeners();
    } catch (_) {}
  }

  Future<void> loadFavorites() async {
    try {
      final favs = await apiService.getFavorites();
      favoriteStoreIds = {};
      favoriteProductIds = {};
      for (final f in favs) {
        if (f['type'] == 'store') favoriteStoreIds.add(f['refId'] as int);
        if (f['type'] == 'product') favoriteProductIds.add(f['refId'] as int);
      }
      notifyListeners();
    } catch (_) {}
  }

  bool isFavoriteStore(int storeId) => favoriteStoreIds.contains(storeId);
  bool isFavoriteProduct(int productId) => favoriteProductIds.contains(productId);

  Future<void> toggleFavoriteStore(int storeId) async {
    if (favoriteStoreIds.contains(storeId)) {
      favoriteStoreIds.remove(storeId);
    } else {
      favoriteStoreIds.add(storeId);
    }
    notifyListeners();
    try {
      await apiService.toggleFavorite('store', storeId);
    } catch (_) {
      // revert on failure
      if (favoriteStoreIds.contains(storeId)) {
        favoriteStoreIds.remove(storeId);
      } else {
        favoriteStoreIds.add(storeId);
      }
      notifyListeners();
    }
  }

  Future<void> toggleFavoriteProduct(int productId) async {
    if (favoriteProductIds.contains(productId)) {
      favoriteProductIds.remove(productId);
    } else {
      favoriteProductIds.add(productId);
    }
    notifyListeners();
    try {
      await apiService.toggleFavorite('product', productId);
    } catch (_) {
      if (favoriteProductIds.contains(productId)) {
        favoriteProductIds.remove(productId);
      } else {
        favoriteProductIds.add(productId);
      }
      notifyListeners();
    }
  }
}
