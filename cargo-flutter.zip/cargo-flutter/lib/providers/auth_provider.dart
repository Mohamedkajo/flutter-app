import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';
import '../services/api_service.dart';
import '../config/api_config.dart';

enum AuthStatus { unknown, authenticated, unauthenticated }

class AuthProvider extends ChangeNotifier {
  AuthStatus _status = AuthStatus.unknown;
  User? _user;
  String? _token;
  String? _error;

  AuthStatus get status => _status;
  User? get user => _user;
  String? get token => _token;
  String? get error => _error;
  bool get isLoggedIn => _status == AuthStatus.authenticated;

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token = prefs.getString(ApiConfig.tokenKey);
    final userJson = prefs.getString(ApiConfig.userKey);
    if (_token != null && userJson != null) {
      try {
        _user = User.fromJson(jsonDecode(userJson) as Map<String, dynamic>);
        _status = AuthStatus.authenticated;
        notifyListeners();
        // Refresh user data
        _user = await apiService.getMe();
        await _saveUser(_user!);
        notifyListeners();
      } catch (_) {
        await logout();
      }
    } else {
      _status = AuthStatus.unauthenticated;
      notifyListeners();
    }
  }

  Future<bool> login(String email, String password) async {
    _error = null;
    try {
      final data = await apiService.login(email, password);
      _token = data['token'] as String;
      _user = User.fromJson(data['user'] as Map<String, dynamic>);
      _status = AuthStatus.authenticated;
      await _saveCredentials(_token!, _user!);
      notifyListeners();
      return true;
    } on Exception catch (e) {
      _error = _extractError(e);
      notifyListeners();
      return false;
    }
  }

  Future<bool> register(String name, String email, String password, {String? phone}) async {
    _error = null;
    try {
      final data = await apiService.register(name, email, password, phone: phone);
      _token = data['token'] as String;
      _user = User.fromJson(data['user'] as Map<String, dynamic>);
      _status = AuthStatus.authenticated;
      await _saveCredentials(_token!, _user!);
      notifyListeners();
      return true;
    } on Exception catch (e) {
      _error = _extractError(e);
      notifyListeners();
      return false;
    }
  }

  Future<void> logout() async {
    _token = null;
    _user = null;
    _status = AuthStatus.unauthenticated;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(ApiConfig.tokenKey);
    await prefs.remove(ApiConfig.userKey);
    notifyListeners();
  }

  Future<void> refreshUser() async {
    try {
      _user = await apiService.getMe();
      await _saveUser(_user!);
      notifyListeners();
    } catch (_) {}
  }

  Future<void> _saveCredentials(String token, User user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(ApiConfig.tokenKey, token);
    await _saveUser(user);
  }

  Future<void> _saveUser(User user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(ApiConfig.userKey, jsonEncode(user.toJson()));
  }

  String _extractError(Exception e) {
    if (e is DioException) {
      final data = e.response?.data;
      if (data is Map && data['error'] != null) return data['error'] as String;
    }
    return e.toString();
  }
}
