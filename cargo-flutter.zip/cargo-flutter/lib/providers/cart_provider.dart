import 'package:flutter/material.dart';
import '../models/cart.dart';
import '../services/api_service.dart';

class CartProvider extends ChangeNotifier {
  Cart? _cart;
  bool _loading = false;
  String? _error;

  Cart? get cart => _cart;
  bool get loading => _loading;
  String? get error => _error;
  int get itemCount => _cart?.itemCount ?? 0;
  bool get isEmpty => _cart?.isEmpty ?? true;

  Future<void> fetchCart() async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      _cart = await apiService.getCart();
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
  }

  Future<bool> addItem(int productId, int quantity, {String? note}) async {
    try {
      _cart = await apiService.addToCart(productId, quantity, specialInstructions: note);
      notifyListeners();
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> updateItem(int itemId, int quantity) async {
    try {
      _cart = await apiService.updateCartItem(itemId, quantity);
      notifyListeners();
    } catch (_) {}
  }

  Future<void> removeItem(int itemId) async {
    try {
      _cart = await apiService.removeCartItem(itemId);
      notifyListeners();
    } catch (_) {}
  }

  Future<void> clear() async {
    try {
      _cart = await apiService.clearCart();
      notifyListeners();
    } catch (_) {}
  }

  Future<Order?> checkout(String paymentMethod, {String? note}) async {
    try {
      final order = await apiService.createOrder(paymentMethod: paymentMethod, specialInstructions: note);
      await fetchCart(); // refresh empty cart
      return order;
    } catch (_) {
      return null;
    }
  }
}
