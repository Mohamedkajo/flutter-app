import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../providers/cart_provider.dart';
import '../../widgets/common/cargo_button.dart';
import '../../theme/app_theme.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final _couponController = TextEditingController();
  bool _checkingOut = false;
  String _paymentMethod = 'cash';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<CartProvider>().fetchCart());
  }

  @override
  void dispose() {
    _couponController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('My Cart'),
        leading: GestureDetector(
          onTap: () => context.pop(),
          child: const Icon(Icons.arrow_back),
        ),
        actions: [
          if (!(cart.cart?.isEmpty ?? true))
            TextButton(
              onPressed: () => _showClearConfirm(context, cart),
              child: const Text('Clear', style: TextStyle(color: Colors.white70)),
            ),
        ],
      ),
      body: cart.loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : (cart.cart?.isEmpty ?? true)
              ? _buildEmptyCart()
              : _buildCart(context, cart),
    );
  }

  Widget _buildEmptyCart() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 100, height: 100,
            decoration: const BoxDecoration(color: AppColors.primaryLight, shape: BoxShape.circle),
            child: const Icon(Icons.shopping_cart_outlined, size: 48, color: AppColors.primary),
          ),
          const SizedBox(height: 20),
          const Text('Your cart is empty', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Text('Add items from a store to get started', style: TextStyle(fontSize: 14, color: AppColors.textMuted)),
          const SizedBox(height: 24),
          SizedBox(
            width: 200,
            child: CargoButton(
              label: 'Browse Stores',
              onPressed: () => context.go('/'),
              fullWidth: true,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCart(BuildContext context, CartProvider cart) {
    final c = cart.cart!;
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // Store info
              if (c.storeName != null)
                Container(
                  padding: const EdgeInsets.all(14),
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: AppColors.primarySurface,
                    borderRadius: BorderRadius.circular(AppRadius.lg),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.store_outlined, color: AppColors.primary, size: 18),
                      const SizedBox(width: 8),
                      Text('Ordering from ${c.storeName}',
                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.primary)),
                    ],
                  ),
                ),

              // Cart items
              ...c.items.map((item) => Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppRadius.lg),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
                ),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(AppRadius.md),
                      child: CachedNetworkImage(
                        imageUrl: item.image,
                        width: 70, height: 70,
                        fit: BoxFit.cover,
                        placeholder: (_, __) => Container(width: 70, height: 70, color: AppColors.surface),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.name, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600), maxLines: 2, overflow: TextOverflow.ellipsis),
                          if (item.variant != null)
                            Text(item.variant!, style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
                          const SizedBox(height: 8),
                          Text('EGP ${item.price.toStringAsFixed(0)}',
                              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.primary)),
                        ],
                      ),
                    ),
                    // Quantity controls
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () => cart.updateItem(item.id, item.quantity - 1),
                          child: Container(
                            width: 30, height: 30,
                            decoration: BoxDecoration(
                              color: item.quantity == 1 ? AppColors.coral.withOpacity(0.1) : AppColors.surface,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: item.quantity == 1 ? AppColors.coral.withOpacity(0.3) : AppColors.border),
                            ),
                            child: Icon(
                              item.quantity == 1 ? Icons.delete_outline : Icons.remove,
                              size: 14,
                              color: item.quantity == 1 ? AppColors.coral : AppColors.textSecondary,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 32,
                          child: Text('${item.quantity}',
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                        ),
                        GestureDetector(
                          onTap: () => cart.updateItem(item.id, item.quantity + 1),
                          child: Container(
                            width: 30, height: 30,
                            decoration: BoxDecoration(
                              color: AppColors.primary,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(Icons.add, size: 14, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              )),

              const SizedBox(height: 8),

              // Coupon
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppRadius.lg),
                  border: Border.all(color: AppColors.border),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.local_offer_outlined, color: AppColors.primary, size: 18),
                    const SizedBox(width: 10),
                    Expanded(
                      child: TextField(
                        controller: _couponController,
                        decoration: const InputDecoration(
                          hintText: 'Enter coupon code',
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          isDense: true,
                          contentPadding: EdgeInsets.zero,
                          filled: false,
                        ),
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
                        textCapitalization: TextCapitalization.characters,
                      ),
                    ),
                    TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom(
                        minimumSize: Size.zero, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      ),
                      child: const Text('Apply', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 13)),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Payment method
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppRadius.lg),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Payment Method', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 12),
                    ...['cash', 'wallet', 'card'].map((method) => GestureDetector(
                      onTap: () => setState(() => _paymentMethod = method),
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Row(
                          children: [
                            Container(
                              width: 20, height: 20,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: _paymentMethod == method ? AppColors.primary : AppColors.border,
                                  width: 2,
                                ),
                              ),
                              child: _paymentMethod == method
                                  ? Container(
                                      margin: const EdgeInsets.all(3),
                                      decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.primary),
                                    )
                                  : null,
                            ),
                            const SizedBox(width: 10),
                            Icon(_paymentMethodIcon(method), size: 18, color: AppColors.textSecondary),
                            const SizedBox(width: 8),
                            Text(_paymentMethodLabel(method),
                                style: TextStyle(
                                  fontSize: 13, fontWeight: FontWeight.w500,
                                  color: _paymentMethod == method ? AppColors.primary : AppColors.textPrimary,
                                )),
                          ],
                        ),
                      ),
                    )),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              // Order summary
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(AppRadius.lg),
                  border: Border.all(color: AppColors.border),
                ),
                child: Column(
                  children: [
                    _SummaryRow(label: 'Subtotal', value: 'EGP ${c.subtotal.toStringAsFixed(0)}'),
                    _SummaryRow(label: 'Delivery Fee', value: 'EGP ${c.deliveryFee.toStringAsFixed(0)}'),
                    if (c.discount > 0)
                      _SummaryRow(label: 'Discount', value: '-EGP ${c.discount.toStringAsFixed(0)}', valueColor: AppColors.teal),
                    const Divider(height: 20),
                    _SummaryRow(
                      label: 'Total',
                      value: 'EGP ${c.total.toStringAsFixed(0)}',
                      bold: true,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        // Checkout button
        Container(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
          decoration: const BoxDecoration(
            color: Colors.white,
            boxShadow: [BoxShadow(color: Color(0x1A000000), blurRadius: 12, offset: Offset(0, -4))],
          ),
          child: CargoButton(
            label: _checkingOut ? 'Placing Order...' : 'Place Order • EGP ${c.total.toStringAsFixed(0)}',
            loading: _checkingOut,
            onPressed: () => _checkout(context, cart),
          ),
        ),
      ],
    );
  }

  Future<void> _checkout(BuildContext context, CartProvider cart) async {
    setState(() => _checkingOut = true);
    final order = await cart.checkout(_paymentMethod);
    setState(() => _checkingOut = false);
    if (order != null && context.mounted) {
      context.go('/orders/${order.id}');
    } else if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to place order. Please try again.')),
      );
    }
  }

  void _showClearConfirm(BuildContext context, CartProvider cart) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clear Cart?'),
        content: const Text('All items will be removed from your cart.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          TextButton(
            onPressed: () { Navigator.pop(context); cart.clear(); },
            child: const Text('Clear', style: TextStyle(color: AppColors.coral)),
          ),
        ],
      ),
    );
  }

  IconData _paymentMethodIcon(String method) => switch (method) {
        'wallet' => Icons.account_balance_wallet_outlined,
        'card' => Icons.credit_card_outlined,
        _ => Icons.payments_outlined,
      };

  String _paymentMethodLabel(String method) => switch (method) {
        'wallet' => 'Cargo Wallet',
        'card' => 'Credit / Debit Card',
        _ => 'Cash on Delivery',
      };
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;
  final Color? valueColor;
  const _SummaryRow({required this.label, required this.value, this.bold = false, this.valueColor});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontSize: 13, color: bold ? AppColors.textPrimary : AppColors.textSecondary, fontWeight: bold ? FontWeight.w700 : FontWeight.w400)),
        Text(value, style: TextStyle(fontSize: bold ? 16 : 13, fontWeight: bold ? FontWeight.w800 : FontWeight.w500, color: valueColor ?? (bold ? AppColors.primary : AppColors.textPrimary))),
      ],
    ),
  );
}
