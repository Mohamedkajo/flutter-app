import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:badges/badges.dart' as badges;
import '../../providers/app_provider.dart';
import '../../providers/cart_provider.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/store_card.dart';
import '../../widgets/product_card.dart';
import '../../widgets/flash_sale_banner.dart';
import '../../widgets/common/section_header.dart';
import '../../widgets/common/loading_shimmer.dart';
import '../../theme/app_theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppProvider>().loadHomeData();
      context.read<CartProvider>().fetchCart();
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final cart = context.watch<CartProvider>();
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: RefreshIndicator(
        color: AppColors.primary,
        onRefresh: () => app.loadHomeData(),
        child: CustomScrollView(
          slivers: [
            // App Bar
            SliverAppBar(
              expandedHeight: 100,
              floating: true,
              pinned: false,
              snap: true,
              backgroundColor: AppColors.primary,
              elevation: 0,
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
                  padding: const EdgeInsets.fromLTRB(20, 48, 20, 12),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Row(
                              children: [
                                Icon(Icons.location_on, color: Colors.white70, size: 13),
                                SizedBox(width: 4),
                                Text('DELIVERING TO', style: TextStyle(color: Colors.white70, fontSize: 10, fontWeight: FontWeight.w600, letterSpacing: 1)),
                              ],
                            ),
                            const SizedBox(height: 2),
                            GestureDetector(
                              onTap: () {},
                              child: const Row(
                                children: [
                                  Text('Home - Dubai', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                                  SizedBox(width: 4),
                                  Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 18),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Row(
                        children: [
                          badges.Badge(
                            showBadge: app.unreadCount > 0,
                            badgeContent: Text('${app.unreadCount}', style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700)),
                            badgeStyle: const badges.BadgeStyle(badgeColor: AppColors.coral, padding: EdgeInsets.all(4)),
                            child: GestureDetector(
                              onTap: () => context.push('/notifications'),
                              child: Container(
                                width: 40, height: 40,
                                decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), shape: BoxShape.circle),
                                child: const Icon(Icons.notifications_outlined, color: Colors.white, size: 20),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          badges.Badge(
                            showBadge: cart.itemCount > 0,
                            badgeContent: Text('${cart.itemCount}', style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700)),
                            badgeStyle: const badges.BadgeStyle(badgeColor: AppColors.coral, padding: EdgeInsets.all(4)),
                            child: GestureDetector(
                              onTap: () => context.push('/cart'),
                              child: Container(
                                width: 40, height: 40,
                                decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), shape: BoxShape.circle),
                                child: const Icon(Icons.shopping_bag_outlined, color: Colors.white, size: 20),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),

            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Search bar
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                    child: GestureDetector(
                      onTap: () => context.push('/search'),
                      child: Container(
                        height: 48,
                        decoration: BoxDecoration(
                          color: AppColors.surface,
                          borderRadius: BorderRadius.circular(AppRadius.full),
                          border: Border.all(color: AppColors.border),
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: const Row(
                          children: [
                            Icon(Icons.search, color: AppColors.textMuted, size: 20),
                            SizedBox(width: 10),
                            Text('Search stores, food, products...', style: TextStyle(color: AppColors.textMuted, fontSize: 14)),
                          ],
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  // Featured stores (story carousel)
                  if (app.homeLoading)
                    SizedBox(
                      height: 110,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: 5,
                        separatorBuilder: (_, __) => const SizedBox(width: 12),
                        itemBuilder: (_, __) => const ShimmerBox(width: 68, height: 68, radius: 100),
                      ),
                    )
                  else if (app.featuredStores.isNotEmpty)
                    SizedBox(
                      height: 110,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: app.featuredStores.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 12),
                        itemBuilder: (_, i) => StoreStoryCard(
                          store: app.featuredStores[i],
                          onTap: () => context.push('/stores/${app.featuredStores[i].id}'),
                        ),
                      ),
                    ),

                  const SizedBox(height: 20),

                  // Flash sale
                  if (app.flashSales.isNotEmpty)
                    FlashSaleBanner(
                      flashSale: app.flashSales.first,
                      onTap: () => context.push('/flash-sales'),
                    ),

                  const SizedBox(height: 24),

                  // Categories
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: SectionHeader(
                      title: 'Explore Categories',
                      actionLabel: 'View All',
                      onAction: () => context.push('/stores'),
                    ),
                  ),
                  const SizedBox(height: 14),
                  app.homeLoading
                      ? SizedBox(
                          height: 90,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            itemCount: 6,
                            separatorBuilder: (_, __) => const SizedBox(width: 12),
                            itemBuilder: (_, __) => const ShimmerBox(width: 72, height: 80, radius: 16),
                          ),
                        )
                      : SizedBox(
                          height: 90,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            itemCount: app.categories.length,
                            separatorBuilder: (_, __) => const SizedBox(width: 12),
                            itemBuilder: (_, i) {
                              final cat = app.categories[i];
                              return GestureDetector(
                                onTap: () => context.push('/stores?category=${cat.slug}'),
                                child: Container(
                                  width: 72,
                                  decoration: BoxDecoration(
                                    color: AppColors.surface,
                                    borderRadius: BorderRadius.circular(AppRadius.lg),
                                    border: Border.all(color: AppColors.border),
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(cat.icon, style: const TextStyle(fontSize: 26)),
                                      const SizedBox(height: 6),
                                      Text(cat.name, textAlign: TextAlign.center,
                                          style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),

                  const SizedBox(height: 24),

                  // Nearby stores
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: SectionHeader(
                      title: 'Nearby Stores',
                      subtitle: 'Fast delivery near you',
                      actionLabel: 'See All',
                      onAction: () => context.push('/stores'),
                    ),
                  ),
                  const SizedBox(height: 14),
                  app.homeLoading
                      ? SizedBox(
                          height: 240,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            itemCount: 3,
                            separatorBuilder: (_, __) => const SizedBox(width: 14),
                            itemBuilder: (_, __) => const SizedBox(width: 200, child: StoreCardShimmer()),
                          ),
                        )
                      : SizedBox(
                          height: 240,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            itemCount: app.nearbyStores.length,
                            separatorBuilder: (_, __) => const SizedBox(width: 14),
                            itemBuilder: (_, i) {
                              final store = app.nearbyStores[i];
                              return SizedBox(
                                width: 200,
                                child: StoreCard(
                                  store: store,
                                  onTap: () => context.push('/stores/${store.id}'),
                                  isFavorite: app.isFavoriteStore(store.id),
                                  onFavoriteTap: () => app.toggleFavoriteStore(store.id),
                                ),
                              );
                            },
                          ),
                        ),

                  const SizedBox(height: 24),

                  // Trending products
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: SectionHeader(
                      title: 'Trending Now',
                      subtitle: 'Most ordered today',
                      actionLabel: 'See All',
                      onAction: () => context.push('/stores'),
                    ),
                  ),
                  const SizedBox(height: 14),
                  app.homeLoading
                      ? Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: GridView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.75),
                            itemCount: 4,
                            itemBuilder: (_, __) => const ProductCardShimmer(),
                          ),
                        )
                      : Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          child: GridView.builder(
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.72,
                            ),
                            itemCount: app.trendingProducts.length > 6 ? 6 : app.trendingProducts.length,
                            itemBuilder: (_, i) {
                              final product = app.trendingProducts[i];
                              return ProductCard(
                                product: product,
                                onTap: () => context.push('/products/${product.id}'),
                                onAddToCart: () async {
                                  final ok = await context.read<CartProvider>().addItem(product.id, 1);
                                  if (ok && context.mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text('${product.name} added to cart'), duration: const Duration(seconds: 2)),
                                    );
                                  }
                                },
                                isFavorite: app.isFavoriteProduct(product.id),
                                onFavoriteTap: () => app.toggleFavoriteProduct(product.id),
                              );
                            },
                          ),
                        ),

                  const SizedBox(height: 100),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
