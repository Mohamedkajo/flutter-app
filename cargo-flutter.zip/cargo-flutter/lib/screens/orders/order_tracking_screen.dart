import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../models/order.dart';
import '../../services/api_service.dart';
import '../../theme/app_theme.dart';

class OrderTrackingScreen extends StatefulWidget {
  final int orderId;
  const OrderTrackingScreen({super.key, required this.orderId});

  @override
  State<OrderTrackingScreen> createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends State<OrderTrackingScreen> {
  OrderTracking? _tracking;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadTracking();
  }

  Future<void> _loadTracking() async {
    try {
      final tracking = await apiService.getOrderTracking(widget.orderId);
      setState(() { _tracking = tracking; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Order #${widget.orderId}'),
        leading: GestureDetector(onTap: () => context.pop(), child: const Icon(Icons.arrow_back)),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loadTracking),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
          : _tracking == null
              ? const Center(child: Text('Unable to load tracking'))
              : _buildTracking(),
    );
  }

  Widget _buildTracking() {
    final t = _tracking!;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Map placeholder
          Container(
            height: 200,
            decoration: BoxDecoration(
              color: AppColors.primarySurface,
              borderRadius: BorderRadius.circular(AppRadius.xl),
              border: Border.all(color: AppColors.primaryLight),
            ),
            child: const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.map_outlined, size: 48, color: AppColors.primary),
                  SizedBox(height: 8),
                  Text('Live Map', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w600)),
                  Text('Driver location updating in real-time', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Status card
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: AppColors.primaryGradient,
              borderRadius: BorderRadius.circular(AppRadius.xl),
            ),
            child: Row(
              children: [
                Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), shape: BoxShape.circle),
                  child: const Icon(Icons.delivery_dining, color: Colors.white, size: 24),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        t.status.replaceAll('_', ' ').replaceFirst(t.status[0], t.status[0].toUpperCase()),
                        style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700),
                      ),
                      if (t.eta != null)
                        Text('ETA: ${t.eta}', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Driver info
          if (t.driverName != null)
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppRadius.lg),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  Container(
                    width: 48, height: 48,
                    decoration: BoxDecoration(
                      color: AppColors.primaryLight,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(child: Text('🏍️', style: TextStyle(fontSize: 22))),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(t.driverName!, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                        if (t.driverRating != null)
                          Row(children: [
                            const Icon(Icons.star, color: AppColors.amber, size: 14),
                            const SizedBox(width: 3),
                            Text('${t.driverRating}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                            const Text(' · Your driver', style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                          ]),
                      ],
                    ),
                  ),
                  Row(
                    children: [
                      _DriverAction(icon: Icons.phone_outlined, onTap: () {}),
                      const SizedBox(width: 10),
                      _DriverAction(icon: Icons.chat_bubble_outline, onTap: () {}),
                    ],
                  ),
                ],
              ),
            ),
          const SizedBox(height: 16),

          // Timeline
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(AppRadius.lg),
              border: Border.all(color: AppColors.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Order Timeline', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                const SizedBox(height: 16),
                ...t.timeline.asMap().entries.map((entry) {
                  final i = entry.key;
                  final step = entry.value;
                  final isLast = i == t.timeline.length - 1;
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        children: [
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            width: 22, height: 22,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: step.completed ? AppColors.primary : AppColors.surface,
                              border: Border.all(
                                color: step.completed ? AppColors.primary : AppColors.border,
                                width: 2,
                              ),
                            ),
                            child: step.completed
                                ? const Icon(Icons.check, size: 12, color: Colors.white)
                                : null,
                          ),
                          if (!isLast)
                            Container(
                              width: 2, height: 36,
                              color: step.completed ? AppColors.primaryLight : AppColors.border,
                            ),
                        ],
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Padding(
                          padding: EdgeInsets.only(bottom: isLast ? 0 : 16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(step.label,
                                  style: TextStyle(
                                    fontSize: 13, fontWeight: FontWeight.w600,
                                    color: step.completed ? AppColors.textPrimary : AppColors.textMuted,
                                  )),
                              const SizedBox(height: 2),
                              Text(step.timestamp.length >= 16 ? step.timestamp.substring(11, 16) : '',
                                  style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                }),
              ],
            ),
          ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }
}

class _DriverAction extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _DriverAction({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 38, height: 38,
      decoration: BoxDecoration(
        color: AppColors.primarySurface,
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.primaryLight),
      ),
      child: Icon(icon, color: AppColors.primary, size: 18),
    ),
  );
}
