import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../models/product.dart';
import '../../providers/app_provider.dart';
import '../../providers/cart_provider.dart';
import '../../services/api_service.dart';
import '../../widgets/common/cargo_button.dart';
import '../../theme/app_theme.dart';

class ProductDetailScreen extends StatefulWidget {
  final int productId;
  const ProductDetailScreen({super.key, required this.productId});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  Product? _product;
  bool _loading = true;
  int _quantity = 1;
  ProductVariant? _selectedVariant;
  final Set<int> _selectedAddonIds = {};
  String? _note;
  bool _addingToCart = false;

  @override
  void initState() {
    super.initState();
    _loadProduct();
  }

  Future<void> _loadProduct() async {
    try {
      final product = await apiService.getProduct(widget.productId);
      setState(() { _product = product; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  double get _totalPrice {
    if (_product == null) return 0;
    final base = _selectedVariant?.price ?? _product!.price;
    final addons = _product!.addons
        .where((a) => _selectedAddonIds.contains(a.id))
        .fold(0.0, (sum, a) => sum + a.price);
    return (base + addons) * _quantity;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.primary)));
    }
    if (_product == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('Product not found')));
    }
    final p = _product!;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 280,
            pinned: true,
            backgroundColor: AppColors.primary,
            leading: GestureDetector(
              onTap: () => context.pop(),
              child: Container(
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.9), shape: BoxShape.circle),
                child: const Icon(Icons.arrow_back, color: AppColors.textPrimary, size: 20),
              ),
            ),
            actions: [
              Consumer<AppProvider>(builder: (_, app, __) => GestureDetector(
                onTap: () => app.toggleFavoriteProduct(p.id),
                child: Container(
                  margin: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.white.withOpacity(0.9), shape: BoxShape.circle),
                  padding: const EdgeInsets.all(8),
                  child: Icon(
                    app.isFavoriteProduct(p.id) ? Icons.favorite : Icons.favorite_border,
                    color: app.isFavoriteProduct(p.id) ? AppColors.coral : AppColors.textMuted,
                    size: 18,
                  ),
                ),
              )),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: CachedNetworkImage(
                imageUrl: p.image,
                fit: BoxFit.cover,
                placeholder: (_, __) => Container(color: AppColors.primaryLight),
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Product header
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(p.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                                const SizedBox(height: 4),
                                Text(p.storeName, style: const TextStyle(fontSize: 13, color: AppColors.textMuted)),
                              ],
                            ),
                          ),
                          if (p.hasDiscount)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(color: AppColors.coral, borderRadius: BorderRadius.circular(AppRadius.full)),
                              child: Text('-${p.discountPercent}%', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12)),
                            ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          RatingBarIndicator(rating: p.rating, itemBuilder: (_, __) => const Icon(Icons.star, color: AppColors.amber), itemCount: 5, itemSize: 14),
                          const SizedBox(width: 6),
                          Text('${p.rating}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                          const SizedBox(width: 4),
                          Text('(${p.reviewCount} reviews)', style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
                          const Spacer(),
                          if (p.preparationTime != null)
                            Row(children: [
                              const Icon(Icons.access_time_outlined, size: 13, color: AppColors.textMuted),
                              const SizedBox(width: 4),
                              Text(p.preparationTime!, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
                            ]),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Text('EGP ${p.price.toStringAsFixed(0)}',
                              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.primary)),
                          if (p.originalPrice != null) ...[
                            const SizedBox(width: 8),
                            Text('EGP ${p.originalPrice!.toStringAsFixed(0)}',
                                style: const TextStyle(fontSize: 15, color: AppColors.textMuted, decoration: TextDecoration.lineThrough)),
                          ],
                        ],
                      ),
                      if (p.description != null) ...[
                        const SizedBox(height: 12),
                        Text(p.description!, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6)),
                      ],
                    ],
                  ),
                ),

                // Variants
                if (p.variants.isNotEmpty) ...[
                  const Divider(height: 8, color: AppColors.surface),
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Choose Size', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 12),
                        Wrap(
                          spacing: 10,
                          runSpacing: 10,
                          children: p.variants.map((v) => GestureDetector(
                            onTap: () => setState(() => _selectedVariant = v),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                              decoration: BoxDecoration(
                                color: _selectedVariant?.id == v.id ? AppColors.primary : AppColors.surface,
                                borderRadius: BorderRadius.circular(AppRadius.full),
                                border: Border.all(color: _selectedVariant?.id == v.id ? AppColors.primary : AppColors.border),
                              ),
                              child: Column(
                                children: [
                                  Text(v.name, style: TextStyle(
                                    fontSize: 13, fontWeight: FontWeight.w600,
                                    color: _selectedVariant?.id == v.id ? Colors.white : AppColors.textPrimary,
                                  )),
                                  Text('EGP ${v.price.toStringAsFixed(0)}', style: TextStyle(
                                    fontSize: 11,
                                    color: _selectedVariant?.id == v.id ? Colors.white70 : AppColors.textMuted,
                                  )),
                                ],
                              ),
                            ),
                          )).toList(),
                        ),
                      ],
                    ),
                  ),
                ],

                // Addons
                if (p.addons.isNotEmpty) ...[
                  const Divider(height: 8, color: AppColors.surface),
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Extras', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        const Text('Optional add-ons', style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                        const SizedBox(height: 12),
                        ...p.addons.map((addon) => GestureDetector(
                          onTap: () => setState(() {
                            if (_selectedAddonIds.contains(addon.id)) {
                              _selectedAddonIds.remove(addon.id);
                            } else {
                              _selectedAddonIds.add(addon.id);
                            }
                          }),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 8),
                            child: Row(
                              children: [
                                AnimatedContainer(
                                  duration: const Duration(milliseconds: 150),
                                  width: 22, height: 22,
                                  decoration: BoxDecoration(
                                    color: _selectedAddonIds.contains(addon.id) ? AppColors.primary : Colors.transparent,
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(
                                      color: _selectedAddonIds.contains(addon.id) ? AppColors.primary : AppColors.border,
                                      width: 1.5,
                                    ),
                                  ),
                                  child: _selectedAddonIds.contains(addon.id)
                                      ? const Icon(Icons.check, size: 13, color: Colors.white)
                                      : null,
                                ),
                                const SizedBox(width: 12),
                                Expanded(child: Text(addon.name, style: const TextStyle(fontSize: 14))),
                                Text('+EGP ${addon.price.toStringAsFixed(0)}',
                                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.primary)),
                              ],
                            ),
                          ),
                        )),
                      ],
                    ),
                  ),
                ],

                // Special instructions
                const Divider(height: 8, color: AppColors.surface),
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Special Instructions', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      const Text('Optional', style: TextStyle(fontSize: 12, color: AppColors.textMuted)),
                      const SizedBox(height: 10),
                      TextField(
                        maxLines: 3,
                        onChanged: (v) => _note = v.isEmpty ? null : v,
                        decoration: const InputDecoration(
                          hintText: 'e.g. No onions, extra sauce on the side...',
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 100),
              ],
            ),
          ),
        ],
      ),

      // Bottom bar
      bottomNavigationBar: Container(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
        decoration: const BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(color: Color(0x1A000000), blurRadius: 16, offset: Offset(0, -4))],
        ),
        child: Row(
          children: [
            // Quantity selector
            Container(
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(AppRadius.md),
                border: Border.all(color: AppColors.border),
              ),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () { if (_quantity > 1) setState(() => _quantity--); },
                    child: Container(
                      width: 36, height: 44,
                      child: const Icon(Icons.remove, size: 16, color: AppColors.textPrimary),
                    ),
                  ),
                  SizedBox(
                    width: 28,
                    child: Text('$_quantity', textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                  ),
                  GestureDetector(
                    onTap: () => setState(() => _quantity++),
                    child: Container(
                      width: 36, height: 44,
                      child: const Icon(Icons.add, size: 16, color: AppColors.textPrimary),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: CargoButton(
                label: _addingToCart ? 'Adding...' : 'Add to Cart • EGP ${_totalPrice.toStringAsFixed(0)}',
                loading: _addingToCart,
                onPressed: !p.isAvailable ? null : () async {
                  setState(() => _addingToCart = true);
                  final ok = await context.read<CartProvider>().addItem(p.id, _quantity, note: _note);
                  if (!mounted) return;
                  setState(() => _addingToCart = false);
                  if (ok) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('${p.name} added to cart!'),
                        action: SnackBarAction(label: 'View Cart', onPressed: () => context.push('/cart'), textColor: AppColors.amber),
                      ),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
