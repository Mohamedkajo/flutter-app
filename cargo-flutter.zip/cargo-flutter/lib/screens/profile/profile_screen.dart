import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/app_provider.dart';
import '../../theme/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.user;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 180,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 64, height: 64,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withOpacity(0.2),
                                border: Border.all(color: Colors.white.withOpacity(0.4), width: 2),
                              ),
                              child: Center(
                                child: Text(
                                  user?.initials ?? '?',
                                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: Colors.white),
                                ),
                              ),
                            ),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(user?.name ?? 'Guest', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white)),
                                  const SizedBox(height: 2),
                                  Text(user?.email ?? '', style: const TextStyle(fontSize: 13, color: Colors.white70)),
                                ],
                              ),
                            ),
                            GestureDetector(
                              onTap: () {},
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(AppRadius.full),
                                  border: Border.all(color: Colors.white.withOpacity(0.3)),
                                ),
                                child: const Text('Edit', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(AppRadius.full),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Text('⭐', style: TextStyle(fontSize: 13)),
                              const SizedBox(width: 6),
                              Text('${user?.loyaltyPoints ?? 0} loyalty points', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Quick stats
                  Row(
                    children: [
                      _StatCard(icon: Icons.receipt_long_outlined, label: 'Orders', value: '12', onTap: () => context.push('/orders')),
                      const SizedBox(width: 12),
                      _StatCard(icon: Icons.favorite_border, label: 'Favourites', value: '8', onTap: () {}),
                      const SizedBox(width: 12),
                      _StatCard(icon: Icons.account_balance_wallet_outlined, label: 'Wallet', value: 'EGP 350', onTap: () => context.push('/wallet')),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Menu sections
                  _MenuSection(title: 'Account', items: [
                    _MenuItem(icon: Icons.person_outlined, label: 'Personal Info', onTap: () {}),
                    _MenuItem(icon: Icons.location_on_outlined, label: 'Saved Addresses', onTap: () {}),
                    _MenuItem(icon: Icons.local_offer_outlined, label: 'My Coupons', onTap: () => context.push('/coupons')),
                    _MenuItem(icon: Icons.account_balance_wallet_outlined, label: 'Wallet & Payments', onTap: () => context.push('/wallet')),
                  ]),

                  const SizedBox(height: 12),

                  _MenuSection(title: 'Support', items: [
                    _MenuItem(icon: Icons.help_outline, label: 'Help Center', onTap: () {}),
                    _MenuItem(icon: Icons.chat_bubble_outline, label: 'Live Chat', onTap: () {}),
                    _MenuItem(icon: Icons.star_outline, label: 'Rate the App', onTap: () {}),
                  ]),

                  const SizedBox(height: 12),

                  _MenuSection(title: 'Settings', items: [
                    _MenuItem(icon: Icons.notifications_outlined, label: 'Notifications', onTap: () => context.push('/notifications')),
                    _MenuItem(icon: Icons.language_outlined, label: 'Language', trailing: 'English', onTap: () {}),
                    _MenuItem(icon: Icons.dark_mode_outlined, label: 'Dark Mode', isSwitch: true, onTap: () {}),
                    _MenuItem(icon: Icons.privacy_tip_outlined, label: 'Privacy Policy', onTap: () {}),
                    _MenuItem(icon: Icons.description_outlined, label: 'Terms of Service', onTap: () {}),
                  ]),

                  const SizedBox(height: 12),

                  // Logout
                  GestureDetector(
                    onTap: () => _confirmLogout(context),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(AppRadius.lg),
                        border: Border.all(color: AppColors.coral.withOpacity(0.3)),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.logout, color: AppColors.coral, size: 20),
                          SizedBox(width: 12),
                          Text('Sign Out', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.coral)),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 8),
                  const Text('Cargo v1.0.0', style: TextStyle(fontSize: 11, color: AppColors.textMuted)),
                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _confirmLogout(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Sign Out?'),
        content: const Text('Are you sure you want to sign out of your account?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              context.read<AuthProvider>().logout();
              context.go('/login');
            },
            child: const Text('Sign Out', style: TextStyle(color: AppColors.coral)),
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final VoidCallback onTap;
  const _StatCard({required this.icon, required this.label, required this.value, required this.onTap});

  @override
  Widget build(BuildContext context) => Expanded(
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadius.lg),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          children: [
            Icon(icon, color: AppColors.primary, size: 22),
            const SizedBox(height: 6),
            Text(value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
            Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
          ],
        ),
      ),
    ),
  );
}

class _MenuSection extends StatelessWidget {
  final String title;
  final List<_MenuItem> items;
  const _MenuSection({required this.title, required this.items});

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 8),
        child: Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textMuted, letterSpacing: 0.8)),
      ),
      Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadius.lg),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          children: items.asMap().entries.map((entry) {
            final i = entry.key;
            final item = entry.value;
            return Column(
              children: [
                if (i > 0) const Divider(height: 1, indent: 52),
                item,
              ],
            );
          }).toList(),
        ),
      ),
    ],
  );
}

class _MenuItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? trailing;
  final bool isSwitch;
  final VoidCallback onTap;
  const _MenuItem({required this.icon, required this.label, this.trailing, this.isSwitch = false, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      child: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(color: AppColors.primarySurface, borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: AppColors.primary, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500))),
          if (trailing != null)
            Text(trailing!, style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
          if (isSwitch)
            Switch(value: false, onChanged: (_) {}, activeColor: AppColors.primary)
          else
            const Icon(Icons.chevron_right, size: 18, color: AppColors.textMuted),
        ],
      ),
    ),
  );
}
