import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../models/store.dart';
import '../../models/product.dart';
import '../../services/api_service.dart';
import '../../widgets/store_card.dart';
import '../../widgets/product_card.dart';
import '../../providers/cart_provider.dart';
import 'package:provider/provider.dart';
import '../../theme/app_theme.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> with SingleTickerProviderStateMixin {
  final _controller = TextEditingController();
  late TabController _tabController;
  List<Store> _stores = [];
  List<Product> _products = [];
  bool _loading = false;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _controller.dispose();
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _search(String q) async {
    if (q.trim().isEmpty) {
      setState(() { _stores = []; _products = []; _query = ''; });
      return;
    }
    setState(() { _loading = true; _query = q; });
    try {
      final results = await Future.wait([
        apiService.listStores(search: q),
        apiService.listProducts(search: q),
      ]);
      setState(() {
        _stores = results[0] as List<Store>;
        _products = results[1] as List<Product>;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        titleSpacing: 0,
        title: TextField(
          controller: _controller,
          autofocus: true,
          onChanged: (v) {
            if (v.length >= 2 || v.isEmpty) _search(v);
          },
          style: const TextStyle(color: Colors.white, fontSize: 15),
          decoration: const InputDecoration(
            hintText: 'Search stores, food, products...',
            hintStyle: TextStyle(color: Colors.white54),
            border: InputBorder.none,
            filled: false,
          ),
        ),
        actions: [
          if (_controller.text.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear, color: Colors.white70),
              onPressed: () { _controller.clear(); _search(''); },
            ),
        ],
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white54,
          indicatorColor: Colors.white,
          tabs: [
            Tab(text: 'Stores (${_stores.length})'),
            Tab(text: 'Products (${_products.length})'),
          ],
        ),
      ),
      body: _query.isEmpty
          ? _buildPlaceholder()
          : _loading
              ? const Center(child: CircularProgressIndicator(color: AppColors.primary))
              : TabBarView(
                  controller: _tabController,
                  children: [
                    _StoreResults(stores: _stores),
                    _ProductResults(products: _products),
                  ],
                ),
    );
  }

  Widget _buildPlaceholder() {
    final suggestions = ['Kofta', 'Pizza', 'Coffee', 'Groceries', 'Pharmacy', 'Sushi'];
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Popular Searches', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textMuted)),
          const SizedBox(height: 12),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: suggestions.map((s) => GestureDetector(
              onTap: () { _controller.text = s; _search(s); },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.circular(AppRadius.full),
                  border: Border.all(color: AppColors.border),
                ),
                child: Text(s, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
              ),
            )).toList(),
          ),
        ],
      ),
    );
  }
}

class _StoreResults extends StatelessWidget {
  final List<Store> stores;
  const _StoreResults({required this.stores});

  @override
  Widget build(BuildContext context) {
    if (stores.isEmpty) {
      return const Center(child: Text('No stores found', style: TextStyle(color: AppColors.textMuted)));
    }
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.72,
      ),
      itemCount: stores.length,
      itemBuilder: (_, i) => StoreCard(
        store: stores[i],
        onTap: () => context.push('/stores/${stores[i].id}'),
      ),
    );
  }
}

class _ProductResults extends StatelessWidget {
  final List<Product> products;
  const _ProductResults({required this.products});

  @override
  Widget build(BuildContext context) {
    if (products.isEmpty) {
      return const Center(child: Text('No products found', style: TextStyle(color: AppColors.textMuted)));
    }
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.72,
      ),
      itemCount: products.length,
      itemBuilder: (_, i) {
        final p = products[i];
        return ProductCard(
          product: p,
          onTap: () => context.push('/products/${p.id}'),
          onAddToCart: () async {
            await context.read<CartProvider>().addItem(p.id, 1);
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${p.name} added'), duration: const Duration(seconds: 2)),
              );
            }
          },
        );
      },
    );
  }
}
