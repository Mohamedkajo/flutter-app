import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:badges/badges.dart' as badges;
import '../../models/store.dart';
import '../../models/product.dart';
import '../../providers/app_provider.dart';
import '../../providers/cart_provider.dart';
import '../../services/api_service.dart';
import '../../widgets/product_card.dart';
import '../../theme/app_theme.dart';

class StoreDetailScreen extends StatefulWidget {
  final int storeId;
  const StoreDetailScreen({super.key, required this.storeId});

  @override
  State<StoreDetailScreen> createState() => _StoreDetailScreenState();
}

class _StoreDetailScreenState extends State<StoreDetailScreen> with SingleTickerProviderStateMixin {
  Store? _store;
  List<Product> _products = [];
  bool _loading = true;
  String? _selectedCategory;
  late TabController _tabController;
  List<String> _categories = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 1, vsync: this);
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final results = await Future.wait([
        apiService.getStore(widget.storeId),
        apiService.getStoreProducts(widget.storeId),
      ]);
      final store = results[0] as Store;
      final products = results[1] as List<Product>;
      final cats = products.map((p) => p.categoryName).toSet().toList();
      setState(() {
        _store = store;
        _products = products;
        _categories = cats;
        _tabController = TabController(length: cats.isEmpty ? 1 : cats.length + 1, vsync: this);
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  List<Product> get _filteredProducts {
    if (_selectedCategory == null) return _products;
    return _products.where((p) => p.categoryName == _selectedCategory).toList();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.primary)));
    }
    if (_store == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('Store not found')));
    }

    final store = _store!;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // Hero banner
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            backgroundColor: AppColors.primary,
            leading: GestureDetector(
              onTap: () => context.pop(),
              child: Container(
                margin: const EdgeInsets.all(8),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.9), shape: BoxShape.circle),
                child: const Icon(Icons.arrow_back, color: AppColors.textPrimary, size: 20),
              ),
            ),
            actions: [
              Consumer<AppProvider>(
                builder: (_, app, __) => GestureDetector(
                  onTap: () => app.toggleFavoriteStore(store.id),
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.9), shape: BoxShape.circle),
                    padding: const EdgeInsets.all(8),
                    child: Icon(
                      app.isFavoriteStore(store.id) ? Icons.favorite : Icons.favorite_border,
                      color: app.isFavoriteStore(store.id) ? AppColors.coral : AppColors.textMuted,
                      size: 18,
                    ),
                  ),
                ),
              ),
              badges.Badge(
                showBadge: cart.itemCount > 0,
                badgeContent: Text('${cart.itemCount}', style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w700)),
                badgeStyle: const badges.BadgeStyle(badgeColor: AppColors.coral),
                child: GestureDetector(
                  onTap: () => context.push('/cart'),
                  child: Container(
                    margin: const EdgeInsets.all(8),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.9), shape: BoxShape.circle),
                    padding: const EdgeInsets.all(8),
                    child: const Icon(Icons.shopping_bag_outlined, color: AppColors.textPrimary, size: 18),
                  ),
                ),
              ),
              const SizedBox(width: 8),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  CachedNetworkImage(
                    imageUrl: store.bannerImage ?? store.image,
                    fit: BoxFit.cover,
                    placeholder: (_, __) => Container(color: AppColors.primaryLight),
                  ),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Colors.black.withOpacity(0.6)],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Store info card
                Container(
                  color: Colors.white,
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(store.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
                                    if (store.isVerified) ...[
                                      const SizedBox(width: 6),
                                      const Icon(Icons.verified, color: AppColors.primary, size: 18),
                                    ],
                                  ],
                                ),
                                const SizedBox(height: 4),
                                Text('${store.categoryIcon ?? ''} ${store.categoryName}',
                                    style: const TextStyle(fontSize: 13, color: AppColors.textMuted)),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: store.isOpen ? AppColors.teal.withOpacity(0.1) : AppColors.coral.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(AppRadius.full),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 7, height: 7,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: store.isOpen ? AppColors.teal : AppColors.coral,
                                  ),
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  store.isOpen ? 'Open' : 'Closed',
                                  style: TextStyle(
                                    fontSize: 12, fontWeight: FontWeight.w600,
                                    color: store.isOpen ? AppColors.teal : AppColors.coral,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          RatingBarIndicator(
                            rating: store.rating,
                            itemBuilder: (_, __) => const Icon(Icons.star, color: AppColors.amber),
                            itemCount: 5, itemSize: 14,
                          ),
                          const SizedBox(width: 6),
                          Text('${store.rating}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                          const SizedBox(width: 4),
                          Text('(${store.reviewCount} reviews)', style: const TextStyle(fontSize: 12, color: AppColors.textMuted)),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          _StatChip(icon: Icons.access_time_outlined, label: store.deliveryTime, sublabel: 'Delivery'),
                          const SizedBox(width: 12),
                          _StatChip(icon: Icons.delivery_dining_outlined, label: 'EGP ${store.deliveryFee.toInt()}', sublabel: 'Delivery Fee'),
                          const SizedBox(width: 12),
                          _StatChip(icon: Icons.shopping_cart_outlined, label: 'EGP ${store.minOrder.toInt()}', sublabel: 'Min. Order'),
                        ],
                      ),
                      if (store.description != null) ...[
                        const SizedBox(height: 14),
                        Text(store.description!, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.5)),
                      ],
                    ],
                  ),
                ),

                const Divider(height: 8, color: AppColors.surface),

                // Category tabs
                if (_categories.isNotEmpty)
                  Container(
                    color: Colors.white,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      child: Row(
                        children: [
                          _CategoryTab(
                            label: 'All',
                            selected: _selectedCategory == null,
                            onTap: () => setState(() => _selectedCategory = null),
                          ),
                          ..._categories.map((cat) => Padding(
                            padding: const EdgeInsets.only(left: 8),
                            child: _CategoryTab(
                              label: cat,
                              selected: _selectedCategory == cat,
                              onTap: () => setState(() => _selectedCategory = cat),
                            ),
                          )),
                        ],
                      ),
                    ),
                  ),

                const Divider(height: 1, color: AppColors.border),

                // Products grid
                if (_filteredProducts.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(40),
                    child: Center(child: Text('No products found', style: TextStyle(color: AppColors.textMuted))),
                  )
                else
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.72,
                      ),
                      itemCount: _filteredProducts.length,
                      itemBuilder: (_, i) {
                        final product = _filteredProducts[i];
                        return ProductCard(
                          product: product,
                          onTap: () => context.push('/products/${product.id}'),
                          onAddToCart: () async {
                            final ok = await context.read<CartProvider>().addItem(product.id, 1);
                            if (ok && context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('${product.name} added'), duration: const Duration(seconds: 2)),
                              );
                            }
                          },
                        );
                      },
                    ),
                  ),

                const SizedBox(height: 80),
              ],
            ),
          ),
        ],
      ),
      // Cart FAB
      floatingActionButton: cart.itemCount > 0
          ? GestureDetector(
              onTap: () => context.push('/cart'),
              child: Container(
                height: 54,
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  gradient: AppColors.primaryGradient,
                  borderRadius: BorderRadius.circular(AppRadius.full),
                  boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.4), blurRadius: 16, offset: const Offset(0, 6))],
                ),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(AppRadius.full),
                      ),
                      child: Text('${cart.itemCount} items', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                    ),
                    const Text('View Cart', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
                    Text('EGP ${cart.cart?.total.toStringAsFixed(0) ?? '0'}',
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
                  ],
                ),
              ),
            )
          : null,
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}

class _StatChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final String sublabel;
  const _StatChip({required this.icon, required this.label, required this.sublabel});

  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.md),
      ),
      child: Column(
        children: [
          Icon(icon, size: 18, color: AppColors.primary),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
          Text(sublabel, style: const TextStyle(fontSize: 10, color: AppColors.textMuted)),
        ],
      ),
    ),
  );
}

class _CategoryTab extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _CategoryTab({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: selected ? AppColors.primary : AppColors.surface,
        borderRadius: BorderRadius.circular(AppRadius.full),
        border: Border.all(color: selected ? AppColors.primary : AppColors.border),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: selected ? Colors.white : AppColors.textSecondary,
        ),
      ),
    ),
  );
}
