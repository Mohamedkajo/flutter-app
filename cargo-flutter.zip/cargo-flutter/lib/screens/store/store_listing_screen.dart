import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../models/store.dart';
import '../../providers/app_provider.dart';
import '../../providers/cart_provider.dart';
import '../../services/api_service.dart';
import '../../widgets/store_card.dart';
import '../../widgets/common/loading_shimmer.dart';
import '../../theme/app_theme.dart';

class StoreListingScreen extends StatefulWidget {
  const StoreListingScreen({super.key});

  @override
  State<StoreListingScreen> createState() => _StoreListingScreenState();
}

class _StoreListingScreenState extends State<StoreListingScreen> {
  List<Store> _stores = [];
  bool _loading = true;
  String? _selectedCategory;
  String _sortBy = 'rating';

  final _sortOptions = [
    ('rating', 'Top Rated'),
    ('deliveryTime', 'Fastest'),
    ('deliveryFee', 'Cheapest Delivery'),
  ];

  @override
  void initState() {
    super.initState();
    _loadStores();
  }

  Future<void> _loadStores() async {
    setState(() => _loading = true);
    try {
      final stores = await apiService.listStores(
        category: _selectedCategory,
        limit: 40,
      );
      setState(() { _stores = stores; _loading = false; });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  List<Store> get _sortedStores {
    final list = List<Store>.from(_stores);
    switch (_sortBy) {
      case 'deliveryFee':
        list.sort((a, b) => a.deliveryFee.compareTo(b.deliveryFee));
      case 'deliveryTime':
        list.sort((a, b) => a.deliveryTime.compareTo(b.deliveryTime));
      default:
        list.sort((a, b) => b.rating.compareTo(a.rating));
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppProvider>();
    final categories = ['All', ...app.categories.map((c) => c.name)];

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('All Stores'),
        actions: [
          GestureDetector(
            onTap: () => context.push('/search'),
            child: Container(
              margin: const EdgeInsets.only(right: 16),
              child: const Icon(Icons.search),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          // Category filter chips
          Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: categories.map((cat) {
                  final selected = cat == 'All' ? _selectedCategory == null : _selectedCategory == cat;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () {
                        setState(() => _selectedCategory = cat == 'All' ? null : cat);
                        _loadStores();
                      },
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: selected ? AppColors.primary : AppColors.surface,
                          borderRadius: BorderRadius.circular(AppRadius.full),
                          border: Border.all(color: selected ? AppColors.primary : AppColors.border),
                        ),
                        child: Text(cat, style: TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w600,
                          color: selected ? Colors.white : AppColors.textSecondary,
                        )),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          // Sort bar
          Container(
            color: AppColors.surface,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                Text(
                  '${_stores.length} stores',
                  style: const TextStyle(fontSize: 12, color: AppColors.textMuted, fontWeight: FontWeight.w500),
                ),
                const Spacer(),
                const Icon(Icons.sort, size: 16, color: AppColors.textMuted),
                const SizedBox(width: 6),
                DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _sortBy,
                    isDense: true,
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                    items: _sortOptions.map((opt) => DropdownMenuItem(
                      value: opt.$1,
                      child: Text(opt.$2),
                    )).toList(),
                    onChanged: (v) => setState(() => _sortBy = v!),
                  ),
                ),
              ],
            ),
          ),

          // Stores grid
          Expanded(
            child: _loading
                ? GridView.builder(
                    padding: const EdgeInsets.all(16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.72,
                    ),
                    itemCount: 6,
                    itemBuilder: (_, __) => const StoreCardShimmer(),
                  )
                : _sortedStores.isEmpty
                    ? const Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.store_outlined, size: 60, color: AppColors.textMuted),
                            SizedBox(height: 12),
                            Text('No stores found', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      )
                    : RefreshIndicator(
                        onRefresh: _loadStores,
                        color: AppColors.primary,
                        child: GridView.builder(
                          padding: const EdgeInsets.all(16),
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.72,
                          ),
                          itemCount: _sortedStores.length,
                          itemBuilder: (_, i) {
                            final store = _sortedStores[i];
                            return StoreCard(
                              store: store,
                              onTap: () => context.push('/stores/${store.id}'),
                              isFavorite: context.read<AppProvider>().isFavoriteStore(store.id),
                              onFavoriteTap: () => context.read<AppProvider>().toggleFavoriteStore(store.id),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
    );
  }
}
