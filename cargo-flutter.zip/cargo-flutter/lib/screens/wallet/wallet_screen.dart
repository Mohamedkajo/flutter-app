import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/user.dart';
import '../../providers/app_provider.dart';
import '../../services/api_service.dart';
import '../../widgets/common/cargo_button.dart';
import '../../theme/app_theme.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  Wallet? _wallet;
  List<WalletTransaction> _transactions = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    try {
      final results = await Future.wait([
        apiService.getWallet(),
        apiService.getWalletTransactions(),
      ]);
      setState(() {
        _wallet = results[0] as Wallet;
        _transactions = results[1] as List<WalletTransaction>;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            title: const Text('Cargo Wallet'),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(gradient: AppColors.primaryGradient),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24, 56, 24, 20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Available Balance', style: TextStyle(color: Colors.white60, fontSize: 13, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 6),
                        _loading
                            ? const Text('Loading...', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800))
                            : Text(
                                'EGP ${_wallet?.balance.toStringAsFixed(2) ?? '0.00'}',
                                style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800),
                              ),
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(AppRadius.full),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Text('⭐', style: TextStyle(fontSize: 13)),
                              const SizedBox(width: 6),
                              Text('${_wallet?.loyaltyPoints ?? 0} pts',
                                  style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Action buttons
                  Row(
                    children: [
                      Expanded(
                        child: CargoButton(
                          label: 'Top Up',
                          icon: const Icon(Icons.add, color: Colors.white, size: 18),
                          onPressed: () => _showTopUpSheet(context),
                          height: 48,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: CargoButton(
                          label: 'Transfer',
                          icon: const Icon(Icons.swap_horiz, color: AppColors.primary, size: 18),
                          variant: CargoButtonVariant.outline,
                          onPressed: () {},
                          height: 48,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // Transactions
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Transaction History', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  ),
                  const SizedBox(height: 12),

                  if (_loading)
                    const Center(child: CircularProgressIndicator(color: AppColors.primary))
                  else if (_transactions.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 40),
                      child: Center(child: Text('No transactions yet', style: TextStyle(color: AppColors.textMuted))),
                    )
                  else
                    ...(_transactions.map((tx) => _TransactionTile(tx: tx))),

                  const SizedBox(height: 80),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showTopUpSheet(BuildContext context) {
    final amounts = [50.0, 100.0, 200.0, 500.0];
    double? selected;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModal) => Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Top Up Wallet', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              const Text('Select or enter an amount', style: TextStyle(fontSize: 13, color: AppColors.textMuted)),
              const SizedBox(height: 20),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: amounts.map((a) => GestureDetector(
                  onTap: () => setModal(() => selected = a),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                    decoration: BoxDecoration(
                      color: selected == a ? AppColors.primary : AppColors.surface,
                      borderRadius: BorderRadius.circular(AppRadius.full),
                      border: Border.all(color: selected == a ? AppColors.primary : AppColors.border),
                    ),
                    child: Text(
                      'EGP ${a.toInt()}',
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: selected == a ? Colors.white : AppColors.textPrimary,
                      ),
                    ),
                  ),
                )).toList(),
              ),
              const SizedBox(height: 20),
              CargoButton(
                label: selected != null ? 'Top Up EGP ${selected!.toInt()}' : 'Select Amount',
                onPressed: selected != null ? () async {
                  Navigator.pop(ctx);
                  await apiService.topUpWallet(selected!, 'card');
                  _loadData();
                } : null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TransactionTile extends StatelessWidget {
  final WalletTransaction tx;
  const _TransactionTile({required this.tx});

  @override
  Widget build(BuildContext context) {
    final isCredit = tx.isCredit;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppRadius.lg),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(
              color: isCredit ? AppColors.teal.withOpacity(0.1) : AppColors.coral.withOpacity(0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(
              isCredit ? Icons.arrow_downward : Icons.arrow_upward,
              color: isCredit ? AppColors.teal : AppColors.coral,
              size: 18,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(tx.description, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(tx.createdAt.substring(0, 10), style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
              ],
            ),
          ),
          Text(
            '${isCredit ? '+' : '-'}EGP ${tx.amount.toStringAsFixed(0)}',
            style: TextStyle(
              fontSize: 14, fontWeight: FontWeight.w700,
              color: isCredit ? AppColors.teal : AppColors.coral,
            ),
          ),
        ],
      ),
    );
  }
}
