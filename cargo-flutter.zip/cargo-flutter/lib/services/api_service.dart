import 'package:dio/dio.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../config/api_config.dart';
import '../models/category.dart';
import '../models/store.dart';
import '../models/product.dart';
import '../models/cart.dart';
import '../models/order.dart';
import '../models/user.dart';

class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  late final Dio _dio;
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    _dio = Dio(BaseOptions(
      baseUrl: ApiConfig.baseUrl,
      connectTimeout: ApiConfig.connectTimeout,
      receiveTimeout: ApiConfig.receiveTimeout,
      headers: {'Content-Type': 'application/json'},
    ));
    _dio.interceptors.add(PrettyDioLogger(requestBody: true, responseBody: false));
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final prefs = await SharedPreferences.getInstance();
        final token = prefs.getString(ApiConfig.tokenKey);
        if (token != null) {
          options.headers[ApiConfig.authHeaderKey] =
              '${ApiConfig.authHeaderPrefix}$token';
        }
        handler.next(options);
      },
    ));
    _initialized = true;
  }

  Future<T> _get<T>(String path, {Map<String, dynamic>? params, required T Function(dynamic) parse}) async {
    await init();
    final response = await _dio.get(path, queryParameters: params);
    return parse(response.data);
  }

  Future<T> _post<T>(String path, {dynamic data, required T Function(dynamic) parse}) async {
    await init();
    final response = await _dio.post(path, data: data);
    return parse(response.data);
  }

  Future<T> _patch<T>(String path, {dynamic data, required T Function(dynamic) parse}) async {
    await init();
    final response = await _dio.patch(path, data: data);
    return parse(response.data);
  }

  Future<T> _delete<T>(String path, {required T Function(dynamic) parse}) async {
    await init();
    final response = await _dio.delete(path);
    return parse(response.data);
  }

  // ── Auth ──────────────────────────────────────────────────────────────────
  Future<Map<String, dynamic>> login(String email, String password) async {
    final response = await _dio.post('/auth/login', data: {'email': email, 'password': password});
    return response.data as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> register(String name, String email, String password, {String? phone}) async {
    final response = await _dio.post('/auth/register', data: {
      'name': name, 'email': email, 'password': password, if (phone != null) 'phone': phone,
    });
    return response.data as Map<String, dynamic>;
  }

  Future<User> getMe() => _get('/auth/me', parse: (d) => User.fromJson(d as Map<String, dynamic>));

  // ── Categories ────────────────────────────────────────────────────────────
  Future<List<Category>> getCategories() => _get('/categories',
      parse: (d) => (d as List).map((e) => Category.fromJson(e as Map<String, dynamic>)).toList());

  // ── Stores ────────────────────────────────────────────────────────────────
  Future<List<Store>> listStores({String? category, String? search, bool? featured, int limit = 20, int offset = 0}) =>
      _get('/stores', params: {
        if (category != null) 'category': category,
        if (search != null) 'search': search,
        if (featured != null) 'featured': featured,
        'limit': limit, 'offset': offset,
      }, parse: (d) => (d as List).map((e) => Store.fromJson(e as Map<String, dynamic>)).toList());

  Future<List<Store>> getFeaturedStores() => _get('/stores/featured',
      parse: (d) => (d as List).map((e) => Store.fromJson(e as Map<String, dynamic>)).toList());

  Future<List<Store>> getNearbyStores({double? lat, double? lng}) =>
      _get('/stores/nearby', params: {if (lat != null) 'lat': lat, if (lng != null) 'lng': lng},
          parse: (d) => (d as List).map((e) => Store.fromJson(e as Map<String, dynamic>)).toList());

  Future<Store> getStore(int storeId) => _get('/stores/$storeId',
      parse: (d) => Store.fromJson(d as Map<String, dynamic>));

  Future<List<Product>> getStoreProducts(int storeId) => _get('/stores/$storeId/products',
      parse: (d) => (d as List).map((e) => Product.fromJson(e as Map<String, dynamic>)).toList());

  // ── Products ──────────────────────────────────────────────────────────────
  Future<List<Product>> listProducts({String? search, int? storeId, int limit = 20}) =>
      _get('/products', params: {
        if (search != null) 'search': search,
        if (storeId != null) 'storeId': storeId,
        'limit': limit,
      }, parse: (d) => (d as List).map((e) => Product.fromJson(e as Map<String, dynamic>)).toList());

  Future<List<Product>> getTrendingProducts() => _get('/products/trending',
      parse: (d) => (d as List).map((e) => Product.fromJson(e as Map<String, dynamic>)).toList());

  Future<Product> getProduct(int productId) => _get('/products/$productId',
      parse: (d) => Product.fromJson(d as Map<String, dynamic>));

  // ── Cart ──────────────────────────────────────────────────────────────────
  Future<Cart> getCart() => _get('/cart', parse: (d) => Cart.fromJson(d as Map<String, dynamic>));

  Future<Cart> addToCart(int productId, int quantity, {String? specialInstructions}) =>
      _post('/cart/items', data: {
        'productId': productId, 'quantity': quantity,
        if (specialInstructions != null) 'specialInstructions': specialInstructions,
      }, parse: (d) => Cart.fromJson(d as Map<String, dynamic>));

  Future<Cart> updateCartItem(int itemId, int quantity) =>
      _patch('/cart/items/$itemId', data: {'quantity': quantity},
          parse: (d) => Cart.fromJson(d as Map<String, dynamic>));

  Future<Cart> removeCartItem(int itemId) =>
      _delete('/cart/items/$itemId', parse: (d) => Cart.fromJson(d as Map<String, dynamic>));

  Future<Cart> clearCart() => _delete('/cart', parse: (d) => Cart.fromJson(d as Map<String, dynamic>));

  // ── Orders ────────────────────────────────────────────────────────────────
  Future<List<Order>> listOrders({int limit = 20, int offset = 0}) =>
      _get('/orders', params: {'limit': limit, 'offset': offset},
          parse: (d) => (d as List).map((e) => Order.fromJson(e as Map<String, dynamic>)).toList());

  Future<Order> createOrder({required String paymentMethod, String? specialInstructions}) =>
      _post('/orders', data: {
        'paymentMethod': paymentMethod,
        if (specialInstructions != null) 'specialInstructions': specialInstructions,
      }, parse: (d) => Order.fromJson(d as Map<String, dynamic>));

  Future<Order> getOrder(int orderId) => _get('/orders/$orderId',
      parse: (d) => Order.fromJson(d as Map<String, dynamic>));

  Future<Order> cancelOrder(int orderId) =>
      _post('/orders/$orderId/cancel', parse: (d) => Order.fromJson(d as Map<String, dynamic>));

  Future<OrderTracking> getOrderTracking(int orderId) => _get('/orders/$orderId/tracking',
      parse: (d) => OrderTracking.fromJson(d as Map<String, dynamic>));

  // ── Wallet ────────────────────────────────────────────────────────────────
  Future<Wallet> getWallet() => _get('/wallet', parse: (d) => Wallet.fromJson(d as Map<String, dynamic>));

  Future<List<WalletTransaction>> getWalletTransactions() =>
      _get('/wallet/transactions',
          parse: (d) => (d as List).map((e) => WalletTransaction.fromJson(e as Map<String, dynamic>)).toList());

  Future<Wallet> topUpWallet(double amount, String paymentMethod) =>
      _post('/wallet/topup', data: {'amount': amount, 'paymentMethod': paymentMethod},
          parse: (d) => Wallet.fromJson(d as Map<String, dynamic>));

  // ── Coupons ───────────────────────────────────────────────────────────────
  Future<List<Coupon>> getCoupons() => _get('/coupons',
      parse: (d) => (d as List).map((e) => Coupon.fromJson(e as Map<String, dynamic>)).toList());

  Future<Map<String, dynamic>> validateCoupon(String code, double orderAmount) =>
      _post('/coupons/validate', data: {'code': code, 'orderAmount': orderAmount},
          parse: (d) => d as Map<String, dynamic>);

  // ── Flash Sales ───────────────────────────────────────────────────────────
  Future<List<FlashSale>> getFlashSales() => _get('/flash-sales',
      parse: (d) => (d as List).map((e) => FlashSale.fromJson(e as Map<String, dynamic>)).toList());

  // ── Favorites ─────────────────────────────────────────────────────────────
  Future<List<dynamic>> getFavorites() => _get('/favorites', parse: (d) => d as List);

  Future<dynamic> toggleFavorite(String type, int refId) =>
      _post('/favorites/toggle', data: {'type': type, 'refId': refId}, parse: (d) => d);

  // ── Notifications ─────────────────────────────────────────────────────────
  Future<List<Notification>> getNotifications() => _get('/notifications',
      parse: (d) => (d as List).map((e) => Notification.fromJson(e as Map<String, dynamic>)).toList());

  Future<Notification> markNotificationRead(int notificationId) =>
      _post('/notifications/$notificationId/read',
          parse: (d) => Notification.fromJson(d as Map<String, dynamic>));

  // ── User Profile ──────────────────────────────────────────────────────────
  Future<User> getUserProfile() => _get('/users/profile',
      parse: (d) => User.fromJson(d as Map<String, dynamic>));

  Future<User> updateUserProfile({String? name, String? phone}) =>
      _patch('/users/profile', data: {
        if (name != null) 'name': name,
        if (phone != null) 'phone': phone,
      }, parse: (d) => User.fromJson(d as Map<String, dynamic>));
}

final apiService = ApiService();
