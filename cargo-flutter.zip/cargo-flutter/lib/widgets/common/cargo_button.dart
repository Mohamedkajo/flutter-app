import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

enum CargoButtonVariant { primary, secondary, outline, ghost, danger }

class CargoButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final CargoButtonVariant variant;
  final bool loading;
  final bool fullWidth;
  final Widget? icon;
  final double? height;
  final double? fontSize;

  const CargoButton({
    super.key,
    required this.label,
    this.onPressed,
    this.variant = CargoButtonVariant.primary,
    this.loading = false,
    this.fullWidth = true,
    this.icon,
    this.height,
    this.fontSize,
  });

  @override
  Widget build(BuildContext context) {
    final isDisabled = onPressed == null || loading;

    Color bg, fg, borderColor;
    switch (variant) {
      case CargoButtonVariant.primary:
        bg = isDisabled ? AppColors.primaryLight : AppColors.primary;
        fg = Colors.white;
        borderColor = Colors.transparent;
      case CargoButtonVariant.secondary:
        bg = AppColors.coral;
        fg = Colors.white;
        borderColor = Colors.transparent;
      case CargoButtonVariant.outline:
        bg = Colors.transparent;
        fg = AppColors.primary;
        borderColor = AppColors.primary;
      case CargoButtonVariant.ghost:
        bg = AppColors.surface;
        fg = AppColors.textPrimary;
        borderColor = AppColors.border;
      case CargoButtonVariant.danger:
        bg = AppColors.error.withOpacity(0.1);
        fg = AppColors.error;
        borderColor = Colors.transparent;
    }

    Widget content = loading
        ? SizedBox(
            width: 20, height: 20,
            child: CircularProgressIndicator(color: fg, strokeWidth: 2.5),
          )
        : Row(
            mainAxisSize: fullWidth ? MainAxisSize.max : MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[icon!, const SizedBox(width: 8)],
              Text(label, style: TextStyle(fontSize: fontSize ?? 15, fontWeight: FontWeight.w600, color: fg)),
            ],
          );

    return SizedBox(
      width: fullWidth ? double.infinity : null,
      height: height ?? 52,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: isDisabled ? null : onPressed,
            borderRadius: BorderRadius.circular(14),
            child: Ink(
              decoration: BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: borderColor, width: 1.5),
                boxShadow: variant == CargoButtonVariant.primary && !isDisabled
                    ? [BoxShadow(color: AppColors.primary.withOpacity(0.3), blurRadius: 12, offset: const Offset(0, 4))]
                    : [],
              ),
              child: Center(child: content),
            ),
          ),
        ),
      ),
    );
  }
}
