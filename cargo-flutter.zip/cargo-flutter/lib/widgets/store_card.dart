import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import '../models/store.dart';
import '../theme/app_theme.dart';

class StoreCard extends StatelessWidget {
  final Store store;
  final VoidCallback onTap;
  final bool isFavorite;
  final VoidCallback? onFavoriteTap;

  const StoreCard({
    super.key,
    required this.store,
    required this.onTap,
    this.isFavorite = false,
    this.onFavoriteTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppRadius.xl),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 16, offset: const Offset(0, 4)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(AppRadius.xl)),
                  child: CachedNetworkImage(
                    imageUrl: store.image,
                    height: 140,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    placeholder: (_, __) => Container(
                      height: 140,
                      color: AppColors.surface,
                      child: const Icon(Icons.store_outlined, color: AppColors.textMuted, size: 40),
                    ),
                    errorWidget: (_, __, ___) => Container(
                      height: 140,
                      color: AppColors.surface,
                      child: const Icon(Icons.store_outlined, color: AppColors.textMuted, size: 40),
                    ),
                  ),
                ),
                // Gradient overlay
                Positioned(
                  left: 0, right: 0, bottom: 0,
                  child: Container(
                    height: 60,
                    decoration: const BoxDecoration(
                      gradient: AppColors.darkGradient,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(0)),
                    ),
                  ),
                ),
                // Closed badge
                if (!store.isOpen)
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.5),
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(AppRadius.xl)),
                      ),
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.black87,
                            borderRadius: BorderRadius.circular(AppRadius.full),
                          ),
                          child: const Text('Closed', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13)),
                        ),
                      ),
                    ),
                  ),
                // Favorite button
                if (onFavoriteTap != null)
                  Positioned(
                    top: 10, right: 10,
                    child: GestureDetector(
                      onTap: onFavoriteTap,
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 8)]),
                        child: Icon(
                          isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: isFavorite ? AppColors.coral : AppColors.textMuted,
                          size: 18,
                        ),
                      ),
                    ),
                  ),
                // Category tag
                Positioned(
                  bottom: 8, left: 10,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.9),
                      borderRadius: BorderRadius.circular(AppRadius.full),
                    ),
                    child: Text(
                      '${store.categoryIcon ?? ''} ${store.categoryName}',
                      style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
                    ),
                  ),
                ),
                // Verified badge
                if (store.isVerified)
                  Positioned(
                    top: 10, left: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        borderRadius: BorderRadius.circular(AppRadius.full),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.verified, color: Colors.white, size: 10),
                          SizedBox(width: 3),
                          Text('Verified', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w600, color: Colors.white)),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
            // Info
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(store.name, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.textPrimary), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      RatingBarIndicator(
                        rating: store.rating,
                        itemBuilder: (_, __) => const Icon(Icons.star, color: AppColors.amber),
                        itemCount: 5,
                        itemSize: 12,
                      ),
                      const SizedBox(width: 4),
                      Text('${store.rating}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: AppColors.textPrimary)),
                      const SizedBox(width: 4),
                      Text('(${store.reviewCount})', style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      _InfoChip(icon: Icons.access_time_outlined, label: store.deliveryTime),
                      const SizedBox(width: 6),
                      _InfoChip(icon: Icons.delivery_dining_outlined, label: 'EGP ${store.deliveryFee.toInt()}'),
                      if (store.distance != null) ...[
                        const SizedBox(width: 6),
                        _InfoChip(icon: Icons.location_on_outlined, label: '${store.distance!.toStringAsFixed(1)} km'),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 12, color: AppColors.textMuted),
        const SizedBox(width: 3),
        Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, fontWeight: FontWeight.w500)),
      ],
    );
  }
}

/// Compact horizontal story-style circle card used in home screen
class StoreStoryCard extends StatelessWidget {
  final Store store;
  final VoidCallback onTap;

  const StoreStoryCard({super.key, required this.store, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: SizedBox(
        width: 80,
        child: Column(
          children: [
            Container(
              width: 68, height: 68,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: store.isOpen
                    ? const LinearGradient(colors: [AppColors.primary, AppColors.coral], begin: Alignment.topLeft, end: Alignment.bottomRight)
                    : null,
                color: store.isOpen ? null : AppColors.border,
              ),
              padding: const EdgeInsets.all(2.5),
              child: ClipOval(
                child: CachedNetworkImage(
                  imageUrl: store.logo ?? store.image,
                  fit: BoxFit.cover,
                  placeholder: (_, __) => Container(color: AppColors.surface),
                  errorWidget: (_, __, ___) => Container(
                    color: AppColors.primaryLight,
                    child: const Icon(Icons.store, color: AppColors.primary, size: 28),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              store.name,
              maxLines: 2,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w500, color: AppColors.textPrimary, height: 1.3),
            ),
          ],
        ),
      ),
    );
  }
}
